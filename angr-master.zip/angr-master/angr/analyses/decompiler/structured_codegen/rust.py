# pylint:disable=missing-class-docstring,too-many-boolean-expressions,unused-argument
from __future__ import annotations

import logging
from collections import Counter, OrderedDict, defaultdict
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import archinfo

from angr import ailment
from angr.ailment import Block, Expr, Stmt, Tmp
from angr.ailment.block_walker import _dispatch_key
from angr.ailment.expression import (
    Array,
    BinaryOp,
    FunctionLikeMacro,
    Let,
    StackBaseOffset,
    StringLiteral,
    Struct,
)
from angr.ailment.expression import (
    RustEnum as AilRustEnum,
)
from angr.analyses.analysis import Analysis, register_analysis
from angr.analyses.decompiler.peephole_optimizations.cas_intrinsics import cas_intrinsic_name
from angr.analyses.decompiler.region_identifier import MultiNode
from angr.analyses.decompiler.structurer_nodes import (
    BreakNode,
    CascadingConditionNode,
    CodeNode,
    ConditionalBreakNode,
    ConditionNode,
    ContinueNode,
    IncompleteSwitchCaseHeadStatement,
    IncompleteSwitchCaseNode,
    LoopNode,
    SequenceNode,
    SwitchCaseNode,
)
from angr.analyses.decompiler.utils import structured_node_is_simple_return
from angr.analyses.decompiler.variable_map import VariableMap
from angr.errors import UnsupportedNodeTypeError
from angr.knowledge_plugins.cfg.memory_data import MemoryData, MemoryDataSort
from angr.knowledge_plugins.functions import Function
from angr.rust.sim_type import (
    EnumVariant,
    RustSimStruct,
    RustSimType,
    RustSimTypeFunction,
    RustSimTypeInt,
    RustSimTypeReference,
    RustSimTypeStrRef,
)
from angr.rust.structuring.structurer_nodes import IfLetNode, PatternMatchNode
from angr.rust.typehoon.translator import RustTypeTranslator
from angr.rust.utils.demangler import demangle, normalize
from angr.sim_type import (
    SimStruct,
    SimType,
    SimTypeArray,
    SimTypeBottom,
    SimTypeChar,
    SimTypeDouble,
    SimTypeFixedSizeArray,
    SimTypeFloat,
    SimTypeFunction,
    SimTypeInt,
    SimTypeLength,
    SimTypeLongLong,
    SimTypeNum,
    SimTypePointer,
    SimTypeReg,
    SimTypeWideChar,
    TypeRef,
)
from angr.sim_variable import SimMemoryVariable, SimStackVariable, SimTemporaryVariable, SimVariable
from angr.utils.constants import should_use_hex
from angr.utils.loader import is_in_readonly_section, is_in_readonly_segment

from .base import BaseStructuredCodeGenerator, InstructionMapping, PositionMapping, PositionMappingElement

if TYPE_CHECKING:
    import angr
    from angr.knowledge_plugins.variables.variable_manager import VariableManagerInternal


l = logging.getLogger(name=__name__)

INDENT_DELTA = 4


def unpack_typeref(ty):
    if isinstance(ty, TypeRef):
        return ty.type
    if isinstance(ty, RustSimTypeReference):
        ty = ty.copy()
        ty.pts_to = unpack_typeref(ty.pts_to)
    return ty


def unpack_pointer(ty) -> SimType | None:
    if isinstance(ty, RustSimTypeReference):
        return ty.pts_to
    return None


def unpack_array(ty) -> SimType | None:
    if isinstance(ty, SimTypeArray):
        return ty.elem_type
    if isinstance(ty, SimTypeFixedSizeArray):
        return ty.elem_type
    return None


def squash_array_reference(ty):
    pointed_to = unpack_pointer(ty)
    if pointed_to:
        array_of = unpack_array(pointed_to)
        if array_of:
            return RustSimTypeReference(array_of)
    return ty


def qualifies_for_simple_cast(ty1, ty2):
    # converting ty1 to ty2 - can this happen precisely?
    # used to decide whether to add explicit typecasts instead of doing *(int*)&v1
    return (
        ty1.size == ty2.size
        and isinstance(ty1, (RustSimTypeInt, RustSimTypeReference))
        and isinstance(ty2, (RustSimTypeInt, RustSimTypeReference))
    )


def qualifies_for_width_cast(ty):
    # converting ty to a different width - can a scalar cast do it?
    # floats are excluded because a float cast converts the value, not the representation
    # the Rust scalar types are subclasses of these: RustSimTypeInt of SimTypeInt,
    # RustSimTypeReference of SimTypePointer, RustSimTypeBottom of SimTypeBottom
    return isinstance(ty, (SimTypeInt, SimTypeChar, SimTypeNum, SimTypePointer, SimTypeBottom))


def qualifies_for_implicit_cast(ty1, ty2):
    # converting ty1 to ty2 - can this happen without a cast?
    # used to decide whether to omit typecasts from output during promotion
    # this function need to answer the question:
    # when does having a cast vs having an implicit promotion affect the result?
    # the answer: I DON'T KNOW
    if not isinstance(ty1, (RustSimTypeInt, SimTypeChar, SimTypeNum)) or not isinstance(
        ty2, (RustSimTypeInt, SimTypeChar, SimTypeNum)
    ):
        return False

    return (ty1.size or 0) <= (ty2.size or 0)


def extract_terms(expr: RustExpression) -> tuple[int, list[tuple[int, RustExpression]]]:
    # handle unnecessary type casts
    if isinstance(expr, RustTypeCast):
        expr = MakeTypecastsImplicit.collapse(expr.dst_type, expr.expr)
    if (
        isinstance(expr, RustTypeCast)
        and isinstance(expr.dst_type, RustSimTypeInt)
        and isinstance(expr.src_type, RustSimTypeInt)
        and expr.dst_type.size == expr.src_type.size
        and expr.dst_type.signed != expr.src_type.signed
    ):
        # (unsigned int)(a + 60)  ==>  a + 60, assuming a + 60 is an int
        expr = expr.expr

    if isinstance(expr, RustConstant):
        return expr.value, []
    # elif isinstance(expr, CUnaryOp) and expr.op == 'Minus'
    if isinstance(expr, RustBinaryOp) and expr.op == "Add":
        c1, t1 = extract_terms(expr.lhs)
        c2, t2 = extract_terms(expr.rhs)
        return c1 + c2, t1 + t2
    if isinstance(expr, RustBinaryOp) and expr.op == "Sub":
        c1, t1 = extract_terms(expr.lhs)
        c2, t2 = extract_terms(expr.rhs)
        return c1 - c2, t1 + [(-c, t) for c, t in t2]
    if isinstance(expr, RustBinaryOp) and expr.op == "Mul":
        if isinstance(expr.lhs, RustConstant):
            c, t = extract_terms(expr.rhs)
            return c * expr.lhs.value, [(c1 * expr.lhs.value, t1) for c1, t1 in t]
        if isinstance(expr.rhs, RustConstant):
            c, t = extract_terms(expr.lhs)
            return c * expr.rhs.value, [(c1 * expr.rhs.value, t1) for c1, t1 in t]
        return 0, [(1, expr)]
    if isinstance(expr, RustBinaryOp) and expr.op == "Shl":
        if isinstance(expr.rhs, RustConstant):
            c, t = extract_terms(expr.lhs)
            return c << expr.rhs.value, [(c1 << expr.rhs.value, t1) for c1, t1 in t]
        return 0, [(1, expr)]
    return 0, [(1, expr)]


def is_machine_word_size_type(type_: SimType, arch: archinfo.Arch) -> bool:
    return isinstance(type_, SimTypeReg) and type_.size == arch.bits


def guess_value_type(value: float, project: angr.Project) -> SimType | None:
    if not isinstance(value, int):
        return None
    if project.kb.functions.contains_addr(value):
        # might be a function pointer
        return RustSimTypeReference(SimTypeBottom(label="void")).with_arch(project.arch)
    if value > 4096:
        sec = project.loader.find_section_containing(value)
        if sec is not None and sec.is_readable:
            return RustSimTypeReference(SimTypeBottom(label="void")).with_arch(project.arch)
        seg = project.loader.find_segment_containing(value)
        if seg is not None and seg.is_readable:
            return RustSimTypeReference(SimTypeBottom(label="void")).with_arch(project.arch)
    return None


def _with_arch(ty, arch):
    if hasattr(ty, "with_arch"):
        return ty.with_arch(arch)  # pyright: ignore[reportAttributeAccessIssue, reportUnknownMemberType]
    return ty


def type_to_rust_repr_chunks(ty: SimType, name=None, name_type=None, full=False, indent_str=""):
    """
    Helper generator function to turn a SimType into generated tuples of (C-string, AST node).
    """
    if isinstance(ty, RustSimStruct) and full:
        # struct def preamble
        yield indent_str, None
        yield "struct ", None
        yield ty.name, ty
        yield " {\n", None

        # each of the fields
        # fields should be indented
        new_indent_str = (
            " " * 4
        ) + indent_str  # TODO: hardcoded as 4 character space indents, which is same as SimStruct.c_repr
        for k, v in ty.fields.items():
            yield new_indent_str, None
            yield from type_to_rust_repr_chunks(
                v, name=k, name_type=RustStructFieldNameDef(k), full=False, indent_str=""
            )
            yield ",\n", None

        # struct def postamble
        yield "} ", None
        # yield ty.name, ty
        yield "\n\n", None
    elif isinstance(ty, RustSimType):
        if not name:
            name = "<unknown_name>"
        if not name_type:
            name_type = "<unknown_rust_type>"

        yield indent_str, None
        yield name, name_type
        yield ": ", None
        yield ty.repr(), ty
    # This case was used when generating externs, apparently there can be cases where the name is not known
    elif ty is None:
        if not name:
            name = "<unknown_name>"
        if not name_type:
            name_type = "<unknown_rust_type>"
        yield "<missing-type> ", None
        yield name, name_type
    else:
        yield from type_to_rust_repr_chunks(
            RustSimTypeInt(ty.size or 0),
            name=name,
            name_type=name_type,
            full=full,
            indent_str=indent_str,
        )


#
#   Rust Representation Classes
#


class RustConstruct:
    """
    Represents a program construct in C.
    Acts as the base class for all other representation constructions.
    """

    __slots__ = ("codegen",)

    def __init__(self, codegen):
        self.codegen: RustStructuredCodeGenerator = codegen

    def c_repr(self, indent=0, pos_to_node=None, pos_to_addr=None, addr_to_pos=None):
        """
        Creates the C representation of the code and displays it by
        constructing a large string. This function is called by each program function that needs to be decompiled.
        The map_pos_to_node and map_pos_to_addr act as position maps for the location of each variable and statement to
        be tracked for later GUI operations. The map_pos_to_addr also contains expressions that are nested inside of
        statements.
        """

        pending_stmt_comments = dict(self.codegen.stmt_comments)
        pending_expr_comments = dict(self.codegen.expr_comments)

        def mapper(chunks):
            # start all positions at beginning of document
            pos = 0

            last_insn_addr = None

            # track all variables so we can tell if this is a declaration or not
            used_vars = set()

            # get each string and object representation of the chunks
            for s, obj in chunks:
                # filter out anything that is not a statement or expression object
                if isinstance(obj, (RustStatement, RustExpression)):
                    # only add statements/expressions that can be address tracked into map_pos_to_addr
                    obj_tags = getattr(obj, "tags", None)
                    if obj_tags is not None and "ins_addr" in obj_tags:
                        if isinstance(obj, RustVariable) and obj not in used_vars:
                            used_vars.add(obj)
                        else:
                            last_insn_addr = obj_tags["ins_addr"]

                            # all valid statements and expressions should be added to map_pos_to_addr and
                            # tracked for instruction mapping from disassembly
                            if pos_to_addr is not None:
                                pos_to_addr.add_mapping(pos, len(s), obj)
                            if addr_to_pos is not None:
                                addr_to_pos.add_mapping(obj_tags["ins_addr"], pos)

                    # add all variables, constants, and function calls to map_pos_to_node for highlighting
                    # add ops to pos_to_node but NOT ast_to_pos
                    if (
                        isinstance(
                            obj,
                            (
                                RustVariable,
                                RustConstant,
                                RustStructField,
                                RustIndexedVariable,
                                RustVariableField,
                                RustBinaryOp,
                                RustUnaryOp,
                                RustAssignment,
                                RustFunctionCall,
                            ),
                        )
                        and pos_to_node is not None
                    ):
                        pos_to_node.add_mapping(pos, len(s), obj)

                # add (), {}, [], and [20] to mapping for highlighting as well as the full functions name
                elif isinstance(obj, (RustClosingObject, RustFunction, RustArrayTypeLength, RustStructFieldNameDef)):
                    if s is None:
                        continue

                    if pos_to_node is not None:
                        pos_to_node.add_mapping(pos, len(s), obj)

                elif isinstance(obj, SimType):
                    if pos_to_node is not None:
                        if isinstance(obj, TypeRef):
                            pos_to_node.add_mapping(pos, len(s), obj.type)
                        else:
                            pos_to_node.add_mapping(pos, len(s), obj)

                if s.endswith("\n") and last_insn_addr is not None:
                    text = pending_stmt_comments.pop(last_insn_addr, None)
                    if text is not None:
                        todo = "  // " + text
                        pos += len(s) - 1
                        yield s[:-1]
                        pos += len(todo)
                        yield todo
                        s = "\n"

                pos += len(s)
                yield s

                if isinstance(obj, RustExpression) and last_insn_addr is not None:
                    text = pending_expr_comments.pop(last_insn_addr, None)
                    if text is not None:
                        todo = " /*" + text + "*/ "
                        pos += len(todo)
                        yield todo

            if pending_expr_comments or pending_stmt_comments:
                yield "// Orphaned comments\n"
                for text in pending_stmt_comments.values():
                    yield "// " + text + "\n"
                for text in pending_expr_comments.values():
                    yield "/* " + text + "*/\n"

        # A special note about this line:
        # Polymorphism allows that the c_repr_chunks() call will be called
        # by the CFunction class, which will then call each statement within it and construct
        # the chunks that get printed in qccode_edit in angr-management.
        return "".join(mapper(self.c_repr_chunks(indent)))

    def c_repr_chunks(self, indent=0, asexpr=False):
        raise NotImplementedError

    @staticmethod
    def indent_str(indent=0):
        return " " * indent


class RustFunction(RustConstruct):  # pylint:disable=abstract-method
    """
    Represents a function in Rust.
    """

    __slots__ = (
        "addr",
        "arg_list",
        "demangled_name",
        "functy",
        "name",
        "show_demangled_name",
        "statements",
        "unified_local_vars",
        "variable_manager",
        "variables_in_use",
    )

    def __init__(
        self,
        addr,
        name,
        functy: RustSimTypeFunction,
        arg_list: list[RustVariable],
        statements,
        variables_in_use,
        variable_manager,
        demangled_name=None,
        show_demangled_name=True,
        **kwargs,
    ):
        super().__init__(**kwargs)

        self.addr = addr
        self.name = name
        self.functy = functy
        self.arg_list = arg_list
        self.statements = statements
        self.variables_in_use = variables_in_use
        self.variable_manager: VariableManagerInternal = variable_manager
        self.demangled_name = demangled_name
        self.unified_local_vars: dict[SimVariable, set[tuple[RustVariable, SimType]]] = self.get_unified_local_vars()
        self.show_demangled_name = show_demangled_name

    def get_unified_local_vars(self) -> dict[SimVariable, set[tuple[RustVariable, SimType]]]:
        unified_to_var_and_types: dict[SimVariable, set[tuple[RustVariable, SimType]]] = defaultdict(set)

        arg_set: set[SimVariable] = set()
        for arg in self.arg_list:
            # TODO: Handle CIndexedVariable
            if isinstance(arg, RustVariable):
                if arg.unified_variable is not None:
                    arg_set.add(arg.unified_variable)
                else:
                    arg_set.add(arg.variable)

        # output each variable and its type
        for var, cvar in self.variables_in_use.items():
            if isinstance(var, SimMemoryVariable) and not isinstance(var, SimStackVariable):
                # Skip all global variables
                continue

            if var in arg_set or cvar.unified_variable in arg_set:
                continue

            unified_var = self.variable_manager.unified_variable(var)
            if unified_var is not None:
                key = unified_var
                var_type = self.variable_manager.get_variable_type(var)  # FIXME
            else:
                key = var
                var_type = self.variable_manager.get_variable_type(var)

            if var_type is None:
                # This should be good
                var_type = RustSimTypeInt(self.codegen.project.arch.bits)

            unified_to_var_and_types[key].add((cvar, var_type))

        return unified_to_var_and_types

    def variable_list_repr_chunks(self, indent=0):
        def _varname_to_id(varname: str) -> int:
            # extract id from default variable name "v{id}"
            if varname.startswith("v"):
                try:
                    return int(varname[1:])
                except ValueError:
                    pass
            return 0

        indent_str = self.indent_str(indent)

        for variable, cvar_and_vartypes in sorted(
            self.unified_local_vars.items(), key=lambda x: _varname_to_id(x[0].name) if x[0].name else 0
        ):
            yield indent_str, None

            # pick the first cvariable
            # this is enough since highlighting works on the unified variable
            try:
                cvariable = next(iter(cvar_and_vartypes))[0]
            except StopIteration:
                # this should never happen, but pylint complains
                continue

            if variable.name:
                name = variable.name
            elif isinstance(variable, SimTemporaryVariable):
                name = f"tmp_{variable.tmp_id}"
            else:
                name = str(variable)

            # sort by the following:
            #   * if it's a a non-basic type
            #   * the number of occurrences
            #   * the repr of the type itself
            # TODO: The type selection should actually happen during variable unification
            vartypes = [x[1] for x in cvar_and_vartypes]
            count = Counter(vartypes)
            vartypes = sorted(
                count.copy(),
                key=lambda x, ct=count: (isinstance(x, (SimTypeChar, SimTypeInt, SimTypeFloat)), ct[x], repr(x)),
            )

            for i, var_type in enumerate(vartypes):
                var_type = unpack_typeref(var_type)
                if i == 0:
                    yield "let ", None
                    yield from type_to_rust_repr_chunks(var_type, name=name, name_type=cvariable)
                    yield ";  // ", None
                    yield variable.loc_repr(self.codegen.project.arch), None
                # multiple types
                else:
                    if i == 1:
                        yield ", Other Possible Types: ", None
                    else:
                        yield ", ", None
                    if isinstance(var_type, SimType):
                        yield var_type.c_repr(), var_type
                    else:
                        yield str(var_type), var_type
            yield "\n", None

        if self.unified_local_vars:
            yield "\n", None

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent)

        if self.codegen.show_local_types:
            local_types = [unpack_typeref(ty) for ty in self.variable_manager.types.iter_own()]
            for ty in local_types:
                if isinstance(ty, SimStruct):
                    for field in ty.fields.values():
                        if isinstance(field, RustSimTypeReference):
                            if isinstance(field.pts_to, (SimTypeArray, SimTypeFixedSizeArray)):
                                field = field.pts_to.elem_type
                            else:
                                field = field.pts_to
                        if isinstance(field, SimStruct) and field not in local_types:
                            local_types.append(field)

                yield from type_to_rust_repr_chunks(ty, full=True, indent_str=indent_str)

        if self.codegen.show_externs and self.codegen.cexterns:
            for v in sorted(self.codegen.cexterns, key=lambda v: v.variable.name or ""):
                varname = v.c_repr() if v.type is None else v.variable.name
                yield "extern ", None
                yield from type_to_rust_repr_chunks(v.type, name=varname, name_type=v, full=False)
                yield ";\n", None
            yield "\n", None

        yield indent_str, None

        # header comments (if they exist)
        header_comments = (
            self.codegen.kb.comments.get(self.codegen.rust_func.addr, []) if self.codegen.rust_func is not None else []
        )
        if header_comments:
            header_cmt = self._line_wrap_comment("".join(header_comments))
            yield header_cmt, None

        # return type
        yield "fn ", None
        # function name
        normalized_name = demangle(self.name) if self.show_demangled_name and self.demangled_name else self.name
        yield normalized_name, self
        # argument list
        paren = RustClosingObject("(")
        brace = RustClosingObject("{")
        yield "(", paren
        for i, (arg_type, cvariable) in enumerate(zip(self.functy.args, self.arg_list)):
            if i:
                yield ", ", None

            variable = cvariable.unified_variable or cvariable.variable
            yield from type_to_rust_repr_chunks(arg_type, name=variable.name, name_type=cvariable, full=False)

        yield ")", paren
        if self.functy.returnty:
            yield " -> ", None
            yield self.functy.returnty.c_repr(name="").strip(" "), self.functy.returnty
        # function body
        if self.codegen.braces_on_own_lines:
            yield "\n", None
            yield indent_str, None
        else:
            yield " ", None
        yield "{", brace
        yield "\n", None
        yield from self.variable_list_repr_chunks(indent=indent + self.codegen.indent_delta)
        yield from self.statements.c_repr_chunks(indent=indent + self.codegen.indent_delta)
        yield indent_str, None
        yield "}", brace
        yield "\n", None

    @staticmethod
    def _line_wrap_comment(comment: str, width=80) -> str:
        lines = comment.splitlines()
        wrapped_cmt = ""

        for line in lines:
            if len(line) < width:
                wrapped_cmt += line + "\n"
                continue

            for i, c in enumerate(line):
                if i % width == 0 and i != 0:
                    wrapped_cmt += "\n"
                wrapped_cmt += c

            wrapped_cmt += "\n"

        return "".join([f"// {line}\n" for line in wrapped_cmt.splitlines()])


class RustStatement(RustConstruct):  # pylint:disable=abstract-method
    """
    Represents a statement in C.
    """

    __slots__ = ()


class RustExpression(RustConstruct):
    """
    Base class for C expressions.
    """

    __slots__ = (
        "_type",
        "collapsed",
    )

    def __init__(self, collapsed=False, **kwargs):
        super().__init__(**kwargs)
        self._type = None
        self.collapsed = collapsed

    @property
    def type(self):
        raise NotImplementedError(f"Class {type(self)} does not implement type().")

    def set_type(self, v):
        self._type = v

    @staticmethod
    def _try_c_repr_chunks(expr, indent=0):
        if hasattr(expr, "c_repr_chunks"):
            yield from expr.c_repr_chunks(indent=indent, asexpr=True)
        else:
            yield str(expr), expr


class RustStatements(RustStatement):
    """
    Represents a sequence of statements in C.
    """

    __slots__ = ("statements",)

    def __init__(self, statements, **kwargs):
        super().__init__(**kwargs)

        self.statements = statements

    def c_repr_chunks(self, indent=0, asexpr=False):
        for stmt in self.statements:
            yield from stmt.c_repr_chunks(indent=indent, asexpr=asexpr)
            if asexpr:
                yield ", ", None


class RustAILBlock(RustStatement):
    """
    Represents a block of AIL statements.
    """

    __slots__ = ("block",)

    def __init__(self, block, **kwargs):
        super().__init__(**kwargs)

        self.block = block

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        r = str(self.block)
        for stmt in r.split("\n"):
            yield indent_str, None
            yield stmt, None
            yield "\n", None


class RustLoop(RustStatement):  # pylint:disable=abstract-method
    """
    Represents a loop in Rust.
    """

    __slots__ = ()


class RustInfiniteLoop(RustLoop):
    """
    Represents an infinite loop in Rust.
    """

    __slots__ = (
        "body",
        "tags",
    )

    def __init__(self, body, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.body = body
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)

        yield indent_str, None
        yield "loop", None
        brace = RustClosingObject("{")
        if self.codegen.braces_on_own_lines:
            yield "\n", None
            yield indent_str, None
        else:
            yield " ", None
        if self.body is None:
            yield ";", None
            yield "\n", None
        else:
            yield "{", brace
            yield "\n", None
            yield from self.body.c_repr_chunks(indent=indent + self.codegen.indent_delta)
            yield indent_str, None
            yield "}", brace
            yield "\n", None


class RustWhileLoop(RustLoop):
    """
    Represents a while loop in C.
    """

    __slots__ = (
        "body",
        "condition",
        "tags",
    )

    def __init__(self, condition, body, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.condition = condition
        self.body = body
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)

        yield indent_str, None
        yield "while ", None
        paren = RustClosingObject("(")
        brace = RustClosingObject("{")
        yield "(", paren
        if self.condition is None:
            yield "true", self
        else:
            yield from self.condition.c_repr_chunks()
        yield ")", paren
        if self.codegen.braces_on_own_lines:
            yield "\n", None
            yield indent_str, None
        else:
            yield " ", None
        if self.body is None:
            yield ";", None
            yield "\n", None
        else:
            yield "{", brace
            yield "\n", None
            yield from self.body.c_repr_chunks(indent=indent + self.codegen.indent_delta)
            yield indent_str, None
            yield "}", brace
            yield "\n", None


class RustDoWhileLoop(RustLoop):
    """
    Represents a do-while loop in C.
    """

    __slots__ = (
        "body",
        "condition",
        "tags",
    )

    def __init__(self, condition, body, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.condition = condition
        self.body = body
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        brace = RustClosingObject("{")
        paren = RustClosingObject("(")

        yield indent_str, None
        yield "do", self
        if self.codegen.braces_on_own_lines:
            yield "\n", None
            yield indent_str, None
        else:
            yield " ", None
        if self.body is not None:
            yield "{", brace
            yield "\n", None
            yield from self.body.c_repr_chunks(indent=indent + self.codegen.indent_delta)
            yield indent_str, None
            yield "}", brace
        else:
            yield "{", brace
            yield " ", None
            yield "}", brace
        yield " ", None
        yield "while ", self
        yield "(", paren
        if self.condition is None:
            yield "true", self
        else:
            yield from self.condition.c_repr_chunks()
        yield ")", paren
        yield ";\n", self


class RustForLoop(RustStatement):
    """
    Represents a for-loop in C.
    """

    __slots__ = ("body", "condition", "initializer", "iterator", "tags")

    def __init__(self, initializer, condition, iterator, body, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.initializer = initializer
        self.condition = condition
        self.iterator = iterator
        self.body = body

        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        brace = RustClosingObject("{")
        paren = RustClosingObject("(")

        yield indent_str, None
        yield "for ", self
        yield "(", paren
        if self.initializer is not None:
            yield from self.initializer.c_repr_chunks(indent=0, asexpr=True)
        yield "; ", None
        if self.condition is not None:
            yield from self.condition.c_repr_chunks(indent=0)
        yield "; ", None
        if self.iterator is not None:
            yield from self.iterator.c_repr_chunks(indent=0, asexpr=True)
        yield ")", paren

        if self.body is not None:
            if self.codegen.braces_on_own_lines:
                yield "\n", None
                yield indent_str, None
            else:
                yield " ", None

            yield "{", brace
            yield "\n", None
            yield from self.body.c_repr_chunks(indent=indent + self.codegen.indent_delta)
            yield indent_str, None
            yield "}", brace
        else:
            yield ";", None
        yield "\n", None


class RustIfElse(RustStatement):
    """
    Represents an if-else construct in Rust.
    """

    __slots__ = ("condition_and_nodes", "cstyle_ifs", "else_node", "simplify_else_scope", "tags")

    def __init__(
        self,
        condition_and_nodes: list[tuple[RustExpression, RustStatement | None]],
        else_node=None,
        simplify_else_scope=False,
        cstyle_ifs=True,
        tags=None,
        **kwargs,
    ):
        super().__init__(**kwargs)

        self.condition_and_nodes = condition_and_nodes
        self.else_node = else_node
        self.simplify_else_scope = simplify_else_scope
        self.cstyle_ifs = cstyle_ifs
        self.tags = tags

        if not self.condition_and_nodes:
            raise ValueError("You must specify at least one condition")

    @staticmethod
    def _is_single_stmt_node(node):
        return (isinstance(node, RustStatements) and len(node.statements) == 1) or isinstance(
            node, (RustBreak, RustContinue, RustReturn, RustGoto)
        )

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        brace = RustClosingObject("{")

        first_node = True
        for condition, node in self.condition_and_nodes:
            if first_node:
                first_node = False
                yield indent_str, None
            else:
                if self.codegen.braces_on_own_lines:
                    yield "\n", None
                    yield indent_str, None
                else:
                    yield " ", None
                yield "else ", self

            yield "if ", self
            yield from condition.c_repr_chunks()

            if self.codegen.braces_on_own_lines:
                yield "\n", None
                yield indent_str, None
            else:
                yield " ", None

            yield "{", brace
            yield "\n", None

            if node is not None:
                yield from node.c_repr_chunks(indent=self.codegen.indent_delta + indent)

            yield indent_str, None
            yield "}", brace

        if self.else_node is not None:
            brace = RustClosingObject("{")
            if self.simplify_else_scope:
                yield "\n", None
                yield from self.else_node.c_repr_chunks(indent=indent)
            else:
                if self.codegen.braces_on_own_lines:
                    yield "\n", None
                    yield indent_str, None
                else:
                    yield " ", None

                yield "else", self
                if self.codegen.braces_on_own_lines:
                    yield "\n", None
                    yield indent_str, None
                else:
                    yield " ", None

                yield "{", brace
                yield "\n", None
                yield from self.else_node.c_repr_chunks(indent=indent + self.codegen.indent_delta)
                yield indent_str, None
                yield "}", brace

        if not self.simplify_else_scope:
            yield "\n", None


class RustIfBreak(RustStatement):
    """
    Represents an if-break statement in C.
    """

    __slots__ = (
        "condition",
        "cstyle_ifs",
        "tags",
    )

    def __init__(self, condition, cstyle_ifs=True, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.condition = condition
        self.cstyle_ifs = cstyle_ifs
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        paren = RustClosingObject("(")
        brace = RustClosingObject("{")

        yield indent_str, None
        yield "if ", self
        yield "(", paren
        yield from self.condition.c_repr_chunks()
        yield ")", paren
        if self.codegen.braces_on_own_lines or self.cstyle_ifs:
            yield "\n", None
            yield indent_str, None
        else:
            yield " ", None
        if self.cstyle_ifs:
            yield self.indent_str(indent=self.codegen.indent_delta), self
            yield "break;\n", self
        else:
            yield "{", brace
            yield "\n", None
            yield self.indent_str(indent=indent + self.codegen.indent_delta), self
            yield "break;\n", self
            yield indent_str, None
            yield "}", brace
        if not self.cstyle_ifs:
            yield "\n", None


class RustBreak(RustStatement):
    """
    Represents a break statement in C.
    """

    __slots__ = ("tags",)

    def __init__(self, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)

        yield indent_str, None
        yield "break;\n", self


class RustContinue(RustStatement):
    """
    Represents a continue statement in C.
    """

    __slots__ = ("tags",)

    def __init__(self, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)

        yield indent_str, None
        yield "continue;\n", self


class RustSwitchCase(RustStatement):
    """
    Represents a switch-case statement in C.
    """

    __slots__ = ("cases", "default", "switch", "tags")

    def __init__(self, switch, cases, default, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.switch = switch
        self.cases: list[tuple[int | tuple[int], RustStatements]] = cases
        self.default = default
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        paren = RustClosingObject("(")
        brace = RustClosingObject("{")

        yield indent_str, None
        yield "match ", self
        yield "(", paren
        yield from self.switch.c_repr_chunks()
        yield ")", paren
        if self.codegen.braces_on_own_lines:
            yield "\n", None
            yield indent_str, None
        else:
            yield " ", None
        yield "{", brace
        yield "\n", None

        # cases
        indent_str = self.indent_str(indent=indent + self.codegen.indent_delta)
        for id_or_ids, case in self.cases:
            yield indent_str, None
            if isinstance(id_or_ids, int):
                yield f"{id_or_ids}", self
                yield " => {\n", None
            else:
                # fold consecutive case IDs into ranges
                sorted_ids = sorted(id_or_ids)
                ranges = []
                start = end = sorted_ids[0]
                for v in sorted_ids[1:]:
                    if v == end + 1:
                        end = v
                    else:
                        ranges.append((start, end))
                        start = end = v
                ranges.append((start, end))

                for i, (rstart, rend) in enumerate(ranges):
                    if rstart == rend:
                        yield f"{rstart}", self
                    else:
                        yield f"{rstart}..={rend}", self
                    yield " ", None
                    if i != len(ranges) - 1:
                        yield "| ", None
                yield "=> {\n", None
            yield from case.c_repr_chunks(indent=indent + self.codegen.indent_delta * 2)
            yield indent_str, None
            yield "}\n", None

        if self.default is not None:
            yield indent_str, None
            yield "_ => {\n", self
            yield from self.default.c_repr_chunks(indent=indent + self.codegen.indent_delta * 2)
            yield indent_str, None
            yield "}\n", None

        indent_str = self.indent_str(indent=indent)
        yield indent_str, None
        yield "}", brace
        yield "\n", None


class RustPatternMatch(RustStatement):
    """
    Represents a pattern-match statement in Rust.
    """

    __slots__ = ("arms", "default", "scrutinee", "tags")

    def __init__(self, match_expr, cases, default, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.scrutinee = match_expr
        self.arms: list[tuple[tuple[EnumVariant, tuple[RustExpression, ...]], RustStatements]] = cases
        self.default = default
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        paren = RustClosingObject("(")
        brace = RustClosingObject("{")

        yield indent_str, None
        yield "match ", self
        yield from self.scrutinee.c_repr_chunks()
        yield " ", None
        yield "{", brace
        yield "\n", None

        arm_indent_str = self.indent_str(indent=indent + self.codegen.indent_delta)

        # arms
        for (variant, bound_vars), arm in self.arms:
            yield arm_indent_str, None
            yield variant.name, None
            if len(bound_vars):
                yield "(", paren
                for i, bound_var in enumerate(bound_vars):
                    if i > 0:
                        yield ", ", None
                    if bound_var:
                        yield from RustExpression._try_c_repr_chunks(bound_var)
                    else:
                        yield "_", None
                yield ")", paren
            yield " => {\n", self
            yield from arm.c_repr_chunks(indent=indent + 2 * self.codegen.indent_delta)
            yield arm_indent_str, None
            yield "},\n", self

        if self.default is not None:
            yield arm_indent_str, None
            yield "_ => {\n", self
            yield from self.default.c_repr_chunks(indent=indent + 2 * self.codegen.indent_delta)
            yield arm_indent_str, None
            yield "}\n", self

        yield indent_str, None
        yield "}", brace
        yield "\n", None


class RustIfLet(RustStatement):
    """
    Represents an if let statement in Rust.
    """

    __slots__ = ("false_node", "pattern", "scrutinee", "tags", "true_node")

    def __init__(self, pattern, scrutinee, true_node, false_node, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.pattern = pattern
        self.scrutinee = scrutinee
        self.true_node = true_node
        self.false_node = false_node
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        paren = RustClosingObject("(")
        brace = RustClosingObject("{")

        yield indent_str, None
        yield "if let ", self

        variant, bound_vars = self.pattern
        yield variant.name, None
        if len(bound_vars):
            yield "(", paren
            for i, bound_var in enumerate(bound_vars):
                if i > 0:
                    yield ", ", None
                if bound_var:
                    yield from RustExpression._try_c_repr_chunks(bound_var)
                else:
                    yield "_", None
            yield ")", paren

        yield " = ", None
        yield from self.scrutinee.c_repr_chunks()
        yield " ", None
        yield "{", brace
        yield "\n", None
        yield from self.true_node.c_repr_chunks(indent=indent + self.codegen.indent_delta)
        yield indent_str, None
        yield "}", brace

        if self.false_node:
            yield " else ", self
            yield "{", brace
            yield "\n", None
            yield from self.false_node.c_repr_chunks(indent=indent + self.codegen.indent_delta)
            yield indent_str, None
            yield "}", brace

        yield "\n", None


class RustAssignment(RustStatement):
    """
    a = b
    """

    __slots__ = (
        "lhs",
        "rhs",
        "tags",
    )

    def __init__(self, lhs, rhs, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.lhs = lhs
        self.rhs = rhs
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.tags is not None and self.tags.get("hidden"):
            return

        indent_str = self.indent_str(indent=indent)

        yield indent_str, None
        yield from RustExpression._try_c_repr_chunks(self.lhs)

        compound_assignment_ops = {
            "Add": "+",
            "Sub": "-",
            "Mul": "*",
            "Div": "/",
            "And": "&",
            "Xor": "^",
            "Or": "|",
            "Shr": ">>",
            "Shl": "<<",
            "Sar": ">>",
        }

        if not isinstance(self.rhs, RustStruct):
            indent = 0

        if (
            self.codegen.use_compound_assignments
            and isinstance(self.lhs, RustVariable)
            and isinstance(self.rhs, RustBinaryOp)
            and isinstance(self.rhs.lhs, RustVariable)
            and self.lhs.unified_variable is not None
            and self.rhs.lhs.unified_variable is not None
            and self.lhs.unified_variable is self.rhs.lhs.unified_variable
            and self.rhs.op in compound_assignment_ops
        ):
            # a = a + x  =>  a += x
            yield f" {compound_assignment_ops[self.rhs.op]}= ", self
            yield from RustExpression._try_c_repr_chunks(self.rhs.rhs, indent=indent)
        else:
            yield " = ", self
            yield from RustExpression._try_c_repr_chunks(self.rhs, indent=indent)
        if not asexpr:
            yield ";", self
            if self.tags is not None and "comment" in self.tags:
                yield " // " + self.tags["comment"], self
            yield "\n", self


class RustFunctionLikeMacro(RustStatement, RustExpression):
    def __init__(self, name, args, delimiter, is_expr, returnty=None, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.args = args
        self.delimiter = delimiter
        self.is_expr = is_expr
        self.returnty = returnty
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        yield indent_str, None

        yield self.name, None
        yield "!", None
        yield self.delimiter[0], None
        if self.args:
            yield from RustExpression._try_c_repr_chunks(self.codegen._handle(self.args[0]))
            for ele in self.args[1:]:
                yield ", ", None
                yield from RustExpression._try_c_repr_chunks(self.codegen._handle(ele))
        yield self.delimiter[1], None
        if not self.is_expr:
            yield ";\n", None

    @property
    def type(self):
        if self.is_expr:
            return self.returnty or RustSimTypeInt(signed=False).with_arch(self.codegen.project.arch)
        raise RuntimeError(
            "RustFunctionLikeMacro.type should not be accessed if the function call is used as a statement."
        )


class RustFunctionCall(RustStatement, RustExpression):
    """
    func(arg0, arg1)

    :ivar Function callee_func:  The function getting called.
    :ivar is_expr:  True if the return value of the function is written to ret_expr; Essentially, ret_expr = call().
    """

    __slots__ = (
        "args",
        "callee_func",
        "callee_target",
        "callsite_prototype",
        "is_expr",
        "receiver",
        "ret_expr",
        "returning",
        "show_demangled_name",
        "show_disambiguated_name",
        "tags",
    )

    def __init__(
        self,
        callee_target,
        callee_func,
        args,
        returning=True,
        ret_expr=None,
        receiver=None,
        tags=None,
        is_expr: bool = False,
        show_demangled_name=True,
        show_disambiguated_name: bool = True,
        callsite_prototype: RustSimTypeFunction | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.callee_target = callee_target
        self.callee_func: Function | None = callee_func
        self.args = args if args is not None else []
        self.returning = returning
        self.ret_expr = ret_expr
        self.receiver = receiver
        self.tags = tags
        self.is_expr = is_expr
        self.show_demangled_name = show_demangled_name
        self.show_disambiguated_name = show_disambiguated_name
        self.callsite_prototype = callsite_prototype

    @property
    def prototype(self) -> SimTypeFunction | None:  # TODO there should be a prototype for each callsite!
        if self.callsite_prototype:
            return self.callsite_prototype
        if self.callee_func is not None and self.callee_func.prototype is not None:
            return self.callee_func.prototype
        returnty = RustSimTypeInt(signed=False)
        return SimTypeFunction([arg.type for arg in self.args], returnty).with_arch(self.codegen.project.arch)

    @property
    def type(self):
        if self.is_expr:
            proto = self.prototype
            if proto is not None and proto.returnty is not None:
                return proto.returnty
            return RustSimTypeInt(signed=False).with_arch(self.codegen.project.arch)
        raise RuntimeError("CFunctionCall.type should not be accessed if the function call is used as a statement.")

    def c_repr_chunks(self, indent=0, asexpr: bool = False):
        """

        :param indent:  Number of whitespace indentation characters.
        :param asexpr:  True if this call is used as an expression (which means we will skip the generation of
                        semicolons and newlines at the end of the call).
        """

        if asexpr:
            indent = 0

        ret_expr = self.ret_expr
        args = self.args

        indent_str = self.indent_str(indent=indent)
        yield indent_str, None

        if not self.is_expr and ret_expr is not None:
            yield from RustExpression._try_c_repr_chunks(ret_expr)
            yield " = ", None

        # If it's a class member function?
        if self.receiver:
            yield from RustExpression._try_c_repr_chunks(self.receiver)
            yield ".", None

        if self.callee_func is not None:
            func_name = normalize(self.callee_func.name, monopolize=False, concise=self.receiver is not None)
            yield func_name, self
        elif isinstance(self.callee_target, str):
            func_name = normalize(self.callee_target, monopolize=False, concise=self.receiver is not None)
            yield func_name, self
        elif isinstance(self.callee_target, RustStringLiteral):
            func_name = normalize(self.callee_target.data, monopolize=False, concise=self.receiver is not None)
            yield func_name, self
        else:
            yield from RustExpression._try_c_repr_chunks(self.callee_target)

        paren = RustClosingObject("(")
        yield "(", paren

        for i, arg in enumerate(args):
            if i:
                yield ", ", None
            yield from RustExpression._try_c_repr_chunks(arg)

        yield ")", paren

        if self.tags is not None and "propagates_error" in self.tags:
            yield "?", None

        if not self.is_expr and not asexpr:
            yield ";", None
            if not self.returning:
                yield " /* do not return */", None
            yield "\n", None


class RustReturn(RustStatement):
    __slots__ = (
        "retval",
        "tags",
    )

    def __init__(self, retval, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.retval = retval
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)

        if not self.retval:
            yield indent_str, None
            yield "return;\n", self
        else:
            yield indent_str, None
            yield "return ", self
            yield from self.retval.c_repr_chunks(
                indent=indent if isinstance(self.retval, (RustStruct, RustEnum)) else 0
            )
            yield ";\n", self


class RustGoto(RustStatement):
    __slots__ = (
        "tags",
        "target",
        "target_idx",
    )

    def __init__(self, target, target_idx, tags=None, **kwargs):
        super().__init__(**kwargs)

        if isinstance(target, RustConstant):
            # unpack target
            target = target.value

        self.target: int | RustExpression = target
        self.target_idx = target_idx
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        lbl = None
        if self.codegen is not None:
            lbl = (
                self.codegen.map_addr_to_label.get((self.target, self.target_idx))
                if isinstance(self.target, (int, type(None)))
                else None
            )

        yield indent_str, None
        if self.codegen.comment_gotos:
            yield "/* ", None
        yield "goto ", self
        if lbl is None:
            if isinstance(self.target, int):
                yield f"LABEL_{self.target:#x}", None
            else:
                yield from self.target.c_repr_chunks()
        else:
            yield lbl.name, lbl
        yield ";", self
        if self.codegen.comment_gotos:
            yield " */", None
        yield "\n", None


class RustUnsupportedStatement(RustStatement):
    """
    A wrapper for unsupported AIL statement.
    """

    __slots__ = ("stmt",)

    def __init__(self, stmt, **kwargs):
        super().__init__(**kwargs)

        self.stmt = stmt

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)

        yield indent_str, None
        yield str(self.stmt), None
        yield "\n", None


class RustIncompleteSwitchCase(RustStatement):
    """
    An incomplete switch-case construct; only appears in the output when switch-case structuring failed.
    """

    __slots__ = ("cases", "head", "tags")

    def __init__(self, head, cases, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.head = head
        self.cases: list[tuple[int, RustStatements]] = cases
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        indent_str = self.indent_str(indent=indent)
        paren = RustClosingObject("(")
        brace = RustClosingObject("{")

        yield from self.head.c_repr_chunks(indent=indent)
        yield "\n", None
        yield indent_str, None
        yield "match ", self
        yield "(", paren
        yield "/* incomplete */", None
        yield ")", paren
        if self.codegen.braces_on_own_lines:
            yield "\n", None
            yield indent_str, None
        else:
            yield " ", None
        yield "{", brace
        yield "\n", None

        for case_addr, case in self.cases:
            yield indent_str, None
            yield f"{case_addr:#x} =>", self
            yield "\n", None
            yield from case.c_repr_chunks(indent=indent + self.codegen.indent_delta)

        yield indent_str, None
        yield "}", brace
        yield "\n", None


class RustDirtyStatement(RustStatement):
    """
    A dirty expression used as a statement, i.e. only for its side effects.
    """

    __slots__ = ("dirty",)

    def __init__(self, dirty, **kwargs):
        super().__init__(**kwargs)
        self.dirty = dirty

    def c_repr_chunks(self, indent=0, asexpr=False):
        yield self.indent_str(indent=indent), None
        yield from RustExpression._try_c_repr_chunks(self.dirty)
        yield ";", None
        yield "\n", None


class RustLabel(RustStatement):
    """
    Represents a label in C code.
    """

    __slots__ = (
        "block_idx",
        "ins_addr",
        "name",
        "tags",
    )

    def __init__(self, name: str, ins_addr: int | None, block_idx: int | None, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.ins_addr = ins_addr
        self.block_idx = block_idx
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        # indent-_str = self.indent_str(indent=indent)

        yield self.name, self
        yield ":", None
        yield "\n", None


class RustStruct(RustExpression):
    __slots__ = (
        "field_names",
        "fields",
        "name",
        "tags",
    )

    def __init__(self, name, fields, field_names, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.name = name
        self.fields = fields
        self.field_names = field_names
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        brace = RustClosingObject("{")
        if self.collapsed:
            yield "...", self
            return
        indent_str = self.indent_str(indent=indent)
        field_indent_str = self.indent_str(indent=indent + self.codegen.indent_delta)
        yield str(self.name), self
        if not self.field_names:
            yield " {", brace
            yield " }", brace
        else:
            yield " {\n", brace
            for offset, name in self.field_names.items():
                yield field_indent_str, None
                yield name, self
                yield ": ", self
                if offset in self.fields:
                    yield from RustExpression._try_c_repr_chunks(
                        self.fields[offset], indent + self.codegen.indent_delta
                    )
                else:
                    yield "<UNKNOWN>", None
                yield "\n", None
            yield indent_str, None
            yield "}", brace


class RustEnum(RustExpression):
    __slots__ = (
        "fields",
        "name",
        "tags",
    )

    def __init__(self, name, fields, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.name = name
        self.fields = fields
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        paren = RustClosingObject("{")
        if self.collapsed:
            yield "...", self
            return
        yield self.name, self
        yield "(", paren
        for idx, expr in enumerate(self.fields):
            if idx > 0:
                yield ", ", None
            if isinstance(expr, RustStruct) and expr.name == "()":
                yield "()", None
            else:
                yield from RustExpression._try_c_repr_chunks(expr, indent=indent)
        yield ")", paren


class RustStructField(RustExpression):
    __slots__ = (
        "field",
        "offset",
        "struct_type",
        "tags",
    )

    def __init__(self, struct_type: SimStruct, offset, field, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.struct_type = struct_type
        self.offset = offset
        self.field = field
        self.tags = tags

    @property
    def type(self):
        return self.struct_type.fields[self.field]

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return
        yield str(self.field), self


class RustArray(RustExpression):
    __slots__ = ("elements", "tags")

    def __init__(self, elements, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.elements = elements
        self.tags = tags

    def c_repr_chunks(self, indent=0, asexpr=False):
        bracket = RustClosingObject("[")
        yield "[", bracket
        for i, ele in enumerate(self.elements):
            if i > 0:
                yield ", ", self
            yield from RustExpression._try_c_repr_chunks(ele)
        yield "]", bracket


class RustLet(RustExpression):
    __slots__ = ("let_expr", "tags")

    def __init__(self, let_expr: Let, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.let_expr = let_expr

    @property
    def variant(self):
        # The bound enum variant lives in the VariableMap, keyed by the Let's .idx.
        return self.codegen._variable_map.variant(self.let_expr)

    @property
    def type(self):
        return self.variant.type

    def _get_rust_variable(self, def_):
        expr = None
        var = None
        if isinstance(def_, ailment.Stmt.Store):
            expr = def_.addr
            var = self.codegen._variable_map.variable(def_)
        if expr and var is not None:
            var_thing = self.codegen._variable(var, expr.size)
            var_thing.tags = dict(expr.tags)
            if "def_at" in var_thing.tags and "ins_addr" not in var_thing.tags:
                def_at = var_thing.tags["def_at"]
                var_thing.tags["ins_addr"] = getattr(def_at, "ins_addr", None)
            return var_thing
        return None

    def c_repr_chunks(self, indent=0, asexpr=False):
        variant = self.variant
        yield "let ", self
        yield variant.name, self
        paren = RustClosingObject("(")
        if variant.has_fields():
            yield "(", paren
            for idx, def_ in enumerate(self.let_expr.defs):
                if var := self._get_rust_variable(def_):
                    yield from RustExpression._try_c_repr_chunks(var)
                else:
                    yield "<ERROR>", self
                if idx != len(self.let_expr.defs) - 1:
                    yield ", ", self
            yield ")", paren
        yield " = ", self
        yield from RustExpression._try_c_repr_chunks(self.codegen._handle(self.let_expr.src))


class RustStringLiteral(RustExpression):
    __slots__ = ("data", "tags")

    def __init__(self, data, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.data = data
        self._type = RustSimTypeStrRef().with_arch(self.codegen.project.arch)

    @property
    def type(self):
        return self._type

    def c_repr_chunks(self, indent=0, asexpr=False):
        yield '"', None
        yield repr(self.data)[1:-1].replace('"', '\\"'), None
        yield '"', None


class RustFakeVariable(RustExpression):
    """
    An uninterpreted name to display in the decompilation output. Pretty much always represents an error?
    """

    __slots__ = ("name", "tags")

    def __init__(self, name: str, ty: SimType, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self._type = ty.with_arch(self.codegen.project.arch)
        self.tags = tags

    @property
    def type(self):
        return self._type

    def c_repr_chunks(self, indent=0, asexpr=False):
        yield self.name, self


class RustVariable(RustExpression):
    """
    CVariable represents access to a variable with the specified type (`variable_type`).

    `variable` must be a SimVariable.
    """

    __slots__ = (
        "tags",
        "unified_variable",
        "variable",
        "variable_type",
    )

    def __init__(self, variable: SimVariable, unified_variable=None, variable_type=None, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.variable: SimVariable = variable
        self.unified_variable: SimVariable | None = unified_variable
        self.variable_type: SimType = (
            variable_type.with_arch(self.codegen.project.arch)
            if variable_type is not None
            else RustSimTypeInt().with_arch(self.codegen.project.arch)
        )
        self.tags = tags

    @property
    def type(self):
        return self.variable_type

    def c_repr_chunks(self, indent=0, asexpr=False):
        v = self.variable if self.unified_variable is None else self.unified_variable

        if v.name:
            yield v.name, self
        elif isinstance(v, SimTemporaryVariable):
            yield f"tmp_{v.tmp_id}", self
        else:
            yield str(v), self


class RustIndexedVariable(RustExpression):
    """
    Represent a variable (an array) that is indexed.
    """

    def __init__(self, variable: RustExpression, index: RustExpression, variable_type=None, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.variable = variable
        self.index: RustExpression = index
        self._type = variable_type
        self.tags = tags

        if self._type is None and self.variable.type is not None:
            u = unpack_typeref(self.variable.type)
            if isinstance(u, RustSimTypeReference):
                if isinstance(u.pts_to, (SimTypeArray, SimTypeFixedSizeArray)):  # noqa: SIM108
                    # special case: (&array)[x]
                    u = u.pts_to.elem_type
                else:
                    u = u.pts_to
                u = unpack_typeref(u)
            elif isinstance(u, (SimTypeArray, SimTypeFixedSizeArray)):
                u = u.elem_type
                u = unpack_typeref(u)
            else:
                u = None  # this should REALLY be an assert false
            self._type = u

    @property
    def type(self):
        return self._type

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return

        bracket = RustClosingObject("[")
        if not isinstance(self.variable, (RustVariable, RustVariableField)):
            yield "(", None
        yield from self.variable.c_repr_chunks()
        if not isinstance(self.variable, (RustVariable, RustVariableField)):
            yield ")", None
        yield "[", bracket
        yield from RustExpression._try_c_repr_chunks(self.index)
        yield "]", bracket


class RustVariableField(RustExpression):
    """
    Represent a field of a variable.
    """

    def __init__(self, variable: RustExpression, field: RustStructField, var_is_ptr: bool = False, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.variable = variable
        self.field = field
        self.var_is_ptr = var_is_ptr
        self.tags = tags

    @property
    def type(self):
        return self.field.type

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return
        yield from self.variable.c_repr_chunks()
        if self.var_is_ptr:
            yield "->", self
        else:
            yield ".", self
        yield from self.field.c_repr_chunks()


class RustUnaryOp(RustExpression):
    """
    Unary operations.
    """

    __slots__ = (
        "op",
        "operand",
        "tags",
    )

    def __init__(self, op, operand: RustExpression, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.op = op
        self.operand = operand
        self.tags = tags

        if operand.type is not None:
            var_type = unpack_typeref(operand.type)
            if op == "Reference":
                self._type = RustSimTypeReference(var_type).with_arch(self.codegen.project.arch)
            elif op == "Dereference":
                if isinstance(var_type, RustSimTypeReference):
                    self._type = unpack_typeref(var_type.pts_to)
                elif isinstance(var_type, (SimTypeArray, SimTypeFixedSizeArray)):
                    self._type = unpack_typeref(var_type.elem_type)

    @property
    def type(self):
        if self._type is None and self.operand is not None and hasattr(self.operand, "type"):
            self._type = self.operand.type
        return self._type

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return

        OP_MAP = {
            "Not": self._c_repr_chunks_not,
            "Neg": self._c_repr_chunks_neg,
            "BitwiseNeg": self._c_repr_chunks_bitwiseneg,
            "Reference": self._c_repr_chunks_reference,
            "Dereference": self._c_repr_chunks_dereference,
        }

        handler = OP_MAP.get(self.op)
        if handler is not None:
            yield from handler()
        else:
            yield from self._c_repr_chunks_opfirst(self.op)

    #
    # Handlers
    #

    def _c_repr_chunks_opfirst(self, op):
        yield op, self
        paren = RustClosingObject("(")
        yield "(", paren
        yield from RustExpression._try_c_repr_chunks(self.operand)
        yield ")", paren

    def _c_repr_chunks_not(self):
        paren = RustClosingObject("(")
        yield "!", self
        yield "(", paren
        yield from RustExpression._try_c_repr_chunks(self.operand)
        yield ")", paren

    def _c_repr_chunks_bitwiseneg(self):
        paren = RustClosingObject("(")
        yield "~", self
        yield "(", paren
        yield from RustExpression._try_c_repr_chunks(self.operand)
        yield ")", paren

    def _c_repr_chunks_neg(self):
        paren = RustClosingObject("(")
        yield "-", self
        yield "(", paren
        yield from RustExpression._try_c_repr_chunks(self.operand)
        yield ")", paren

    def _c_repr_chunks_reference(self):
        yield "&", self
        yield from RustExpression._try_c_repr_chunks(self.operand)

    def _c_repr_chunks_dereference(self):
        paren = RustClosingObject("(")
        yield "*", self
        yield "(", paren
        yield from RustExpression._try_c_repr_chunks(self.operand)
        yield ")", paren


class RustBinaryOp(RustExpression):
    """
    Binary operations.
    """

    __slots__ = ("_cstyle_null_cmp", "common_type", "lhs", "op", "rhs", "tags")

    def __init__(self, op, lhs, rhs, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.op = op
        self.lhs = lhs
        self.rhs = rhs
        self.tags = tags
        self._cstyle_null_cmp = self.codegen.cstyle_null_cmp

        self.common_type = self.compute_common_type(self.op, self.lhs.type, self.rhs.type)
        if self.op.startswith("Cmp"):
            self._type = SimTypeChar().with_arch(self.codegen.project.arch)
        else:
            self._type = self.common_type

    @staticmethod
    def compute_common_type(op: str, lhs_ty: SimType, rhs_ty: SimType) -> SimType:
        # C spec https://www.open-std.org/jtc1/sc22/wg14/www/docs/n2596.pdf 6.3.1.8 Usual arithmetic conversions
        rhs_ptr = isinstance(rhs_ty, RustSimTypeReference)
        lhs_ptr = isinstance(lhs_ty, RustSimTypeReference)

        if op in ("Add", "Sub"):
            if lhs_ptr and rhs_ptr:
                return SimTypeLength().with_arch(rhs_ty._arch)
            if lhs_ptr:
                return lhs_ty
            if rhs_ptr:
                return rhs_ty

        if lhs_ptr or rhs_ptr:
            # uh oh!
            return SimTypeLength().with_arch(rhs_ty._arch)

        if lhs_ty == rhs_ty:
            return lhs_ty

        lhs_signed = getattr(lhs_ty, "signed", None)
        rhs_signed = getattr(rhs_ty, "signed", None)
        # uhhhhhhhhhh idk
        if lhs_signed is None:
            return lhs_ty
        if rhs_signed is None:
            return rhs_ty

        if lhs_signed == rhs_signed:
            if (lhs_ty.size or 0) > (rhs_ty.size or 0):
                return lhs_ty
            return rhs_ty

        if lhs_signed:
            signed_ty = lhs_ty
            unsigned_ty = rhs_ty
        else:
            signed_ty = rhs_ty
            unsigned_ty = lhs_ty

        if (unsigned_ty.size or 0) >= (signed_ty.size or 0):
            return unsigned_ty
        if (signed_ty.size or 0) > (unsigned_ty.size or 0):
            return signed_ty
        # uh oh!!
        return signed_ty

    @property
    def type(self):
        return self._type

    @property
    def op_precedence(self):
        precedence_list = [
            # lowest precedence
            ["Concat"],
            ["LogicalOr"],
            ["LogicalAnd"],
            ["Or"],
            ["Xor"],
            ["And"],
            ["CmpEQ", "CmpNE"],
            ["CmpLE", "CmpLT", "CmpGT", "CmpGE"],
            ["Shl", "Shr", "Sar"],
            ["Add", "Sub"],
            ["Mul", "Div"],
            # highest precedence
        ]
        for i, sublist in enumerate(precedence_list):
            if self.op in sublist:
                return i
        return len(precedence_list)

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return

        OP_MAP = {
            "Add": self._c_repr_chunks_add,
            "Sub": self._c_repr_chunks_sub,
            "Mul": self._c_repr_chunks_mul,
            "Mull": self._c_repr_chunks_mull,
            "Div": self._c_repr_chunks_div,
            "DivMod": self._c_repr_chunks_divmod,
            "Mod": self._c_repr_chunks_mod,
            "And": self._c_repr_chunks_and,
            "Xor": self._c_repr_chunks_xor,
            "Or": self._c_repr_chunks_or,
            "Shr": self._c_repr_chunks_shr,
            "Shl": self._c_repr_chunks_shl,
            "Sar": self._c_repr_chunks_sar,
            "LogicalAnd": self._c_repr_chunks_logicaland,
            "LogicalOr": self._c_repr_chunks_logicalor,
            "CmpLE": self._c_repr_chunks_cmple,
            "CmpLEs": self._c_repr_chunks_cmple,
            "CmpLT": self._c_repr_chunks_cmplt,
            "CmpLTs": self._c_repr_chunks_cmplt,
            "CmpGT": self._c_repr_chunks_cmpgt,
            "CmpGTs": self._c_repr_chunks_cmpgt,
            "CmpGE": self._c_repr_chunks_cmpge,
            "CmpGEs": self._c_repr_chunks_cmpge,
            "CmpEQ": self._c_repr_chunks_cmpeq,
            "CmpNE": self._c_repr_chunks_cmpne,
            "Concat": self._c_repr_chunks_concat,
            "Rol": self._c_repr_chunks_rol,
            "Ror": self._c_repr_chunks_ror,
            "Index": self._c_repr_chunks_index,
            "AccessField": self._c_repr_chunks_access_field,
        }

        handler = OP_MAP.get(self.op)
        if handler is not None:
            yield from handler()
        else:
            yield from self._c_repr_chunks_opfirst(self.op)

    def _has_const_null_rhs(self) -> bool:
        return isinstance(self.rhs, RustConstant) and self.rhs.value == 0

    #
    # Handlers
    #

    def _c_repr_chunks_opfirst(self, op):
        yield op, self
        paren = RustClosingObject("(")
        yield "(", paren
        yield from RustExpression._try_c_repr_chunks(self.lhs)
        yield ", ", None
        yield from RustExpression._try_c_repr_chunks(self.rhs)
        yield ")", paren

    def _c_repr_chunks(self, op):
        skip_op_and_rhs = False
        if self._cstyle_null_cmp and self._has_const_null_rhs():
            if self.op == "CmpEQ":
                skip_op_and_rhs = True
                yield "!", None
            elif self.op == "CmpNE":
                skip_op_and_rhs = True
        # lhs
        if isinstance(self.lhs, RustBinaryOp) and self.op_precedence > self.lhs.op_precedence:
            paren = RustClosingObject("(")
            yield "(", paren
            yield from self._try_c_repr_chunks(self.lhs)
            yield ")", paren
        else:
            yield from self._try_c_repr_chunks(self.lhs)

        if not skip_op_and_rhs:
            # operator
            yield op, self
            # rhs
            if isinstance(self.rhs, RustBinaryOp) and self.op_precedence > self.rhs.op_precedence - (
                1 if self.op in ["Sub", "Div"] else 0
            ):
                paren = RustClosingObject("(")
                yield "(", paren
                yield from self._try_c_repr_chunks(self.rhs)
                yield ")", paren
            else:
                yield from self._try_c_repr_chunks(self.rhs)

    def _c_repr_chunks_index(self):
        yield from self._try_c_repr_chunks(self.lhs)
        bracket = RustClosingObject("[")
        yield "[", bracket
        yield from self._try_c_repr_chunks(self.rhs)
        yield "]", bracket

    def _c_repr_chunks_access_field(self):
        yield from self._try_c_repr_chunks(self.lhs)
        yield ".", None
        if self.tags is not None and "field_name" in self.tags and self.tags["field_name"] is not None:
            yield self.tags["field_name"], None
        else:
            yield from self._try_c_repr_chunks(self.rhs)

    def _c_repr_chunks_add(self):
        yield from self._c_repr_chunks(" + ")

    def _c_repr_chunks_sub(self):
        yield from self._c_repr_chunks(" - ")

    def _c_repr_chunks_mul(self):
        yield from self._c_repr_chunks(" * ")

    def _c_repr_chunks_mull(self):
        yield from self._c_repr_chunks(" * ")

    def _c_repr_chunks_div(self):
        yield from self._c_repr_chunks(" / ")

    def _c_repr_chunks_divmod(self):
        yield from self._c_repr_chunks(" /m ")

    def _c_repr_chunks_mod(self):
        yield from self._c_repr_chunks(" % ")

    def _c_repr_chunks_and(self):
        yield from self._c_repr_chunks(" & ")

    def _c_repr_chunks_xor(self):
        yield from self._c_repr_chunks(" ^ ")

    def _c_repr_chunks_or(self):
        yield from self._c_repr_chunks(" | ")

    def _c_repr_chunks_shr(self):
        yield from self._c_repr_chunks(" >> ")

    def _c_repr_chunks_shl(self):
        yield from self._c_repr_chunks(" << ")

    def _c_repr_chunks_sar(self):
        yield from self._c_repr_chunks(" >> ")

    def _c_repr_chunks_logicaland(self):
        yield from self._c_repr_chunks(" && ")

    def _c_repr_chunks_logicalor(self):
        yield from self._c_repr_chunks(" || ")

    def _c_repr_chunks_cmple(self):
        yield from self._c_repr_chunks(" <= ")

    def _c_repr_chunks_cmplt(self):
        yield from self._c_repr_chunks(" < ")

    def _c_repr_chunks_cmpgt(self):
        yield from self._c_repr_chunks(" > ")

    def _c_repr_chunks_cmpge(self):
        yield from self._c_repr_chunks(" >= ")

    def _c_repr_chunks_cmpeq(self):
        yield from self._c_repr_chunks(" == ")

    def _c_repr_chunks_cmpne(self):
        yield from self._c_repr_chunks(" != ")

    def _c_repr_chunks_concat(self):
        yield from self._c_repr_chunks(" CONCAT ")

    def _c_repr_chunks_rol(self):
        yield "__ROL__", self
        paren = RustClosingObject("(")
        yield "(", paren
        yield from self._try_c_repr_chunks(self.lhs)
        yield ", ", None
        yield from self._try_c_repr_chunks(self.rhs)
        yield ")", paren

    def _c_repr_chunks_ror(self):
        yield "__ROR__", self
        paren = RustClosingObject("(")
        yield "(", paren
        yield from self._try_c_repr_chunks(self.lhs)
        yield ", ", None
        yield from self._try_c_repr_chunks(self.rhs)
        yield ")", paren


class RustTypeCast(RustExpression):
    __slots__ = (
        "dst_type",
        "expr",
        "src_type",
        "tags",
    )

    def __init__(
        self,
        src_type: SimType | None,
        dst_type: SimType,
        expr: RustExpression,
        tags=None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        # assert isinstance(dst_type, RustSimType)
        arch = self.codegen.project.arch
        self.src_type = _with_arch(src_type or expr.type, arch)
        self.dst_type = _with_arch(dst_type, arch)
        self.expr = expr
        self.tags = tags

    @property
    def type(self):
        if self._type is None:
            return self.dst_type
        return self._type

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return
        paren = RustClosingObject("(")

        if isinstance(self.expr, RustBinaryOp):
            wrapping_paren = True
            yield "(", paren
        else:
            wrapping_paren = False
        yield from RustExpression._try_c_repr_chunks(self.expr)
        if wrapping_paren:
            yield ")", paren

        if self.codegen.show_casts:
            yield " as ", None
            yield f"{self.dst_type.c_repr(name=None)}", self.dst_type


class RustConstant(RustExpression):
    __slots__ = (
        "reference_values",
        "tags",
        "value",
    )

    def __init__(self, value, type_: SimType, reference_values=None, tags: dict | None = None, **kwargs):
        super().__init__(**kwargs)

        self.value = value
        self._type = type_.with_arch(self.codegen.project.arch)
        self.reference_values = reference_values
        self.tags = tags

    @property
    def _ident(self):
        ident = (self.tags or {}).get("ins_addr", None)
        if ident is not None:
            return ("inst", ident)
        return ("val", self.value)

    @property
    def fmt(self):
        return self.codegen.const_formats.get(self._ident, {})

    @property
    def _fmt_setter(self):
        result = self.codegen.const_formats.get(self._ident, None)
        if result is None:
            result = {}
            self.codegen.const_formats[self._ident] = result

        return result

    @property
    def fmt_hex(self):
        result = self.fmt.get("hex", None)
        if result is None:
            result = False
            if isinstance(self.value, int):
                bits = self._type.size if self._type is not None else None
                result = should_use_hex(self.value, bits)
        return result

    @fmt_hex.setter
    def fmt_hex(self, v):
        self._fmt_setter["hex"] = v

    @property
    def fmt_neg(self):
        result = self.fmt.get("neg", None)
        if result is None:
            result = False
            if isinstance(self.value, int):
                value_size = self._type.size if self._type is not None else None
                if (value_size == 32 and 0xF000_0000 <= self.value <= 0xFFFF_FFFF) or (
                    value_size == 64 and 0xF000_0000_0000_0000 <= self.value <= 0xFFFF_FFFF_FFFF_FFFF
                ):
                    result = True

        return result

    @fmt_neg.setter
    def fmt_neg(self, v):
        self._fmt_setter["neg"] = v

    @property
    def fmt_char(self):
        return self.fmt.get("char", False)

    @fmt_char.setter
    def fmt_char(self, v: bool):
        self._fmt_setter["char"] = v

    @property
    def type(self):
        return self._type

    @staticmethod
    def str_to_rust_str(_str, is_heap_str=False, prefix: str = ""):
        repr_str = repr(_str)
        base_str = repr_str[1:-1]
        if repr_str[0] == "'":  # noqa: SIM102
            # check if there's double quotes in the body
            if '"' in base_str:
                base_str = base_str.replace('"', '\\"')
        if is_heap_str:
            return f'String::from({prefix}"{base_str}")'
        return f'{prefix}"{base_str}"'

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return

        # default priority: string references -> variables -> other reference values
        if self.reference_values is not None:
            for v in self.reference_values.values():  # pylint:disable=unused-variable
                if isinstance(v, MemoryData) and v.sort == MemoryDataSort.String and v.content is not None:
                    yield RustConstant.str_to_rust_str(v.content.decode("utf-8")), self
                    return
                elif isinstance(v, str):
                    yield RustConstant.str_to_rust_str(v, is_heap_str=False), self
                    return
                elif isinstance(v, Function):
                    yield demangle(v.name), self
                    return

        if self.reference_values is not None and self._type is not None and self._type in self.reference_values:
            if isinstance(self._type, RustSimTypeInt):
                if isinstance(self.reference_values[self._type], int):
                    yield self.fmt_int(self.reference_values[self._type]), self
                    return
                yield hex(self.reference_values[self._type]), self
            else:
                if isinstance(self.reference_values[self._type], int):
                    yield self.fmt_int(self.reference_values[self._type]), self
                    return
                yield self.reference_values[self.type], self

        elif (
            isinstance(self.value, int)
            and self.value == 0
            and (isinstance(self.type, (RustSimTypeReference, RustSimStruct)))
        ):
            # print NULL instead
            yield "None", self

        elif isinstance(self._type, RustSimTypeReference) and isinstance(self.value, int):
            # Print pointers in hex
            yield hex(self.value), self

        elif isinstance(self.value, bool):
            # C doesn't have true or false, but whatever...
            yield "true" if self.value else "false", self

        elif isinstance(self.value, int):
            str_value = self.fmt_int(self.value)
            yield str_value, self
        else:
            yield str(self.value), self

    def fmt_int(self, value: int) -> str:
        """
        Format an integer using the format setup of the current node.

        :param value:   The integer value to format.
        :return:        The formatted string.
        """

        if self.fmt_neg:
            if value > 0:
                value = value - 2 ** (self._type.size or 0)
            elif value < 0:
                value = value + 2 ** (self._type.size or 0)

        str_value = None
        if self.fmt_char:
            try:
                str_value = f"'{chr(value)}'"
            except ValueError:
                str_value = None

        if str_value is None:
            str_value = hex(value) if self.fmt_hex else str(value)

        return str_value


class RustRegister(RustExpression):
    __slots__ = (
        "reg",
        "tags",
    )

    def __init__(self, reg, tags=None, **kwargs):
        super().__init__(**kwargs)

        self.reg = reg
        self.tags = tags

    @property
    def type(self):
        # FIXME
        return RustSimTypeInt().with_arch(self.codegen.project.arch)

    def c_repr_chunks(self, indent=0, asexpr=False):
        yield str(self.reg), None


class RustITE(RustExpression):
    __slots__ = (
        "cond",
        "iffalse",
        "iftrue",
        "tags",
    )

    def __init__(self, cond, iftrue, iffalse, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.cond = cond
        self.iftrue = iftrue
        self.iffalse = iffalse
        self.tags = tags

    @property
    def type(self):
        return RustSimTypeInt().with_arch(self.codegen.project.arch)

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return
        paren = RustClosingObject("(")
        yield "(", paren
        yield from self.cond.c_repr_chunks()
        yield " ? ", self
        yield from self.iftrue.c_repr_chunks()
        yield " : ", self
        yield from self.iffalse.c_repr_chunks()
        yield ")", paren


class RustMultiStatementExpression(RustExpression):
    """
    (stmt0, stmt1, stmt2, expr)
    """

    __slots__ = ("expr", "stmts", "tags")

    def __init__(self, stmts: RustStatements, expr: RustExpression, tags=None, **kwargs):
        super().__init__(**kwargs)
        self.stmts = stmts
        self.expr = expr
        self.tags = tags

    @property
    def type(self):
        return self.expr.type

    def c_repr_chunks(self, indent=0, asexpr=False):
        paren = RustClosingObject("(")
        yield "(", paren
        yield from self.stmts.c_repr_chunks(indent=0, asexpr=True)
        yield from self.expr.c_repr_chunks()
        yield ")", paren


class RustVEXCCallExpression(RustExpression):
    """
    ccall_name(arg0, arg1, ...)
    """

    __slots__ = (
        "callee",
        "operands",
        "tags",
    )

    def __init__(self, callee: str, operands: list[RustExpression], tags=None, **kwargs):
        super().__init__(**kwargs)
        self.callee = callee
        self.operands = operands
        self.tags = tags

    @property
    def type(self):
        return RustSimTypeInt().with_arch(self.codegen.project.arch)

    def c_repr_chunks(self, indent=0, asexpr=False):
        paren = RustClosingObject("(")
        yield f"{self.callee}", self
        yield "(", paren
        for idx, operand in enumerate(self.operands):
            if idx != 0:
                yield ", ", None
            yield from operand.c_repr_chunks()
        yield ")", paren


class RustDirtyExpression(RustExpression):
    """
    Ideally all dirty expressions should be handled and converted to proper conversions during conversion from VEX to
    AIL. Eventually this class should not be used at all.
    """

    __slots__ = ("dirty",)

    def __init__(self, dirty, **kwargs):
        super().__init__(**kwargs)
        self.dirty = dirty

    @property
    def type(self):
        return RustSimTypeInt().with_arch(self.codegen.project.arch)

    def c_repr_chunks(self, indent=0, asexpr=False):
        if self.collapsed:
            yield "...", self
            return
        yield str(self.dirty), None


class RustClosingObject:
    """
    A class to represent all objects that can be closed by it's correspodning character.
    Examples: (), {}, []
    """

    __slots__ = ("opening_symbol",)

    def __init__(self, opening_symbol):
        self.opening_symbol = opening_symbol


class RustArrayTypeLength:
    """
    A class to represent the type information of fixed-size array lengths.
    Examples: In "char foo[20]", this would be the "[20]".
    """

    __slots__ = ("text",)

    def __init__(self, text):
        self.text = text


class RustStructFieldNameDef:
    """A class to represent the name of a defined field in a struct.
    Needed because it's not a CVariable or a CStructField (because
    CStructField is the access of a CStructField).
    Example: In "struct foo { int bar; }, this would be "bar".
    """

    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name


class RustStructuredCodeGenerator(BaseStructuredCodeGenerator, Analysis):
    def __init__(
        self,
        func,
        sequence,
        indent=0,
        cfg=None,
        func_args: list[SimVariable] | None = None,
        binop_depth_cutoff: int = 16,
        show_casts=True,
        braces_on_own_lines=False,
        use_compound_assignments=True,
        show_local_types=False,
        comment_gotos=False,
        cstyle_null_cmp=True,
        flavor=None,
        stmt_comments=None,
        expr_comments=None,
        show_externs=False,
        externs=None,
        const_formats=None,
        show_demangled_name=True,
        show_disambiguated_name=True,
        ail_graph=None,
        simplify_else_scope=True,
        cstyle_ifs=True,
        omit_func_header=False,
        display_block_addrs=False,
        display_vvar_ids=False,
        min_data_addr: int = 0x400_000,
        notes=None,
        display_notes: bool = True,
        max_str_len: int | None = None,
        prettify_thiscall: bool = False,
        cstyle_void_param: bool = True,
        indent_size: int = INDENT_DELTA,
        variable_map: VariableMap | None = None,
    ):
        super().__init__(
            flavor=flavor,
            notes=notes,
        )

        self._handlers = {
            CodeNode: self._handle_Code,
            SequenceNode: self._handle_Sequence,
            LoopNode: self._handle_Loop,
            ConditionNode: self._handle_Condition,
            CascadingConditionNode: self._handle_CascadingCondition,
            ConditionalBreakNode: self._handle_ConditionalBreak,
            MultiNode: self._handle_MultiNode,
            Block: self._handle_AILBlock,
            BreakNode: self._handle_Break,
            SwitchCaseNode: self._handle_SwitchCase,
            IncompleteSwitchCaseNode: self._handle_IncompleteSwitchCase,
            ContinueNode: self._handle_Continue,
            PatternMatchNode: self._handle_PatternMatch,
            IfLetNode: self._handle_IfLet,
            # AIL statements
            Stmt.Store: self._handle_Stmt_Store,
            Stmt.Assignment: self._handle_Stmt_Assignment,
            Stmt.SideEffectStatement: self._handle_Stmt_SideEffectStatement,
            Stmt.Jump: self._handle_Stmt_Jump,
            Stmt.ConditionalJump: self._handle_Stmt_ConditionalJump,
            Stmt.Return: self._handle_Stmt_Return,
            Stmt.Label: self._handle_Stmt_Label,
            Stmt.WeakAssignment: self._handle_Stmt_Assignment,
            Stmt.DirtyStatement: self._handle_Stmt_Dirty,
            Stmt.CAS: self._handle_Stmt_CAS,
            IncompleteSwitchCaseHeadStatement: self._handle_Stmt_IncompleteSwitchCaseHead,
            # AIL expressions
            Expr.Register: self._handle_Expr_Register,
            Expr.Load: self._handle_Expr_Load,
            Expr.Tmp: self._handle_Expr_Tmp,
            Expr.Const: self._handle_Expr_Const,
            Expr.UnaryOp: self._handle_Expr_UnaryOp,
            Expr.BinaryOp: self._handle_Expr_BinaryOp,
            Expr.Convert: self._handle_Expr_Convert,
            Expr.StackBaseOffset: self._handle_Expr_StackBaseOffset,
            Expr.VEXCCallExpression: self._handle_Expr_VEXCCallExpression,
            Expr.DirtyExpression: self._handle_Expr_Dirty,
            Expr.ITE: self._handle_Expr_ITE,
            Expr.Extract: self._handle_Expr_Extract,
            Expr.Insert: self._handle_Expr_Insert,
            Expr.Reinterpret: self._handle_Reinterpret,
            Expr.MultiStatementExpression: self._handle_MultiStatementExpression,
            Expr.VirtualVariable: self._handle_VirtualVariable,
            Expr.Call: self._handle_Expr_Call,
            Expr.FunctionLikeMacro: self._handle_FunctionLikeMacro,
            StringLiteral: self._handle_Expr_StringLiteral,
            Struct: self._handle_Expr_Struct,
            AilRustEnum: self._handle_Expr_RustEnum,
            Array: self._handle_Expr_Array,
            Let: self._handle_Expr_Let,
        }

        self._func = func
        self._func_args = func_args
        self._cfg = cfg
        self._sequence = sequence
        self._variable_map: VariableMap = variable_map if variable_map is not None else VariableMap()
        self.binop_depth_cutoff = binop_depth_cutoff

        self._variables_in_use: dict | None = None
        self._inlined_strings: set[SimMemoryVariable] = set()
        self._function_pointers: set[SimMemoryVariable] = set()
        self.ailexpr2cnode: dict[tuple[Expr.Expression, bool], RustExpression] | None = None
        self.cnode2ailexpr: dict[RustExpression, Expr.Expression] | None = None
        self._indent = indent
        self.show_casts = show_casts
        self.comment_gotos = comment_gotos
        self.braces_on_own_lines = braces_on_own_lines
        self.use_compound_assignments = use_compound_assignments
        self.show_local_types = show_local_types
        self.cstyle_null_cmp = cstyle_null_cmp
        self.expr_comments: dict[int, str] = expr_comments if expr_comments is not None else {}
        self.stmt_comments: dict[int, str] = stmt_comments if stmt_comments is not None else {}
        self.const_formats: dict[Any, dict[str, Any]] = const_formats if const_formats is not None else {}
        self.externs = externs or set()
        self.show_externs = show_externs
        self.show_demangled_name = show_demangled_name
        self.show_disambiguated_name = show_disambiguated_name
        self.ail_graph = ail_graph
        self.simplify_else_scope = simplify_else_scope
        self.cstyle_ifs = cstyle_ifs
        self.omit_func_header = omit_func_header
        self.display_block_addrs = display_block_addrs
        self.display_vvar_ids = display_vvar_ids
        self.min_data_addr = min_data_addr
        self.text = None
        self.map_pos_to_node = None
        self.map_pos_to_addr = None
        self.map_addr_to_pos = None
        self.map_ast_to_pos: dict[SimVariable, set[PositionMappingElement]] | None = None
        self.map_addr_to_label: dict[tuple[int | None, int | None], RustLabel] = {}
        self.rust_func: RustFunction | None = None
        self.cexterns: set[RustVariable] | None = None
        self.display_notes = display_notes
        self.max_str_len = max_str_len
        self.prettify_thiscall = prettify_thiscall
        self.cstyle_void_param = cstyle_void_param
        self.indent_delta = indent_size

        self._analyze()

    def reapply_options(self, options):
        for option, value in options:
            if option.param == "braces_on_own_lines":
                self.braces_on_own_lines = value
            elif option.param == "show_casts":
                self.show_casts = value
            elif option.param == "comment_gotos":
                self.comment_gotos = value
            elif option.param == "use_compound_assignments":
                self.use_compound_assignments = value
            elif option.param == "show_local_types":
                self.show_local_types = value
            elif option.param == "show_externs":
                self.show_externs = value
            elif option.param == "show_demangled_name":
                self.show_demangled_name = value
            elif option.param == "cstyle_null_cmp":
                self.cstyle_null_cmp = value
            elif option.param == "simplify_else_scope":
                self.simplify_else_scope = value
            elif option.param == "cstyle_ifs":
                self.cstyle_ifs = value
            elif option.param == "cstyle_void_param":
                self.cstyle_void_param = value
            elif option.param == "indent_size":
                self.indent_delta = value

    def _translate_prototype_to_rust(self, prototype: SimTypeFunction):
        translator = RustTypeTranslator(self.project.arch)
        args: list[RustSimType] = [  # pyright: ignore[reportAssignmentType]
            translator.ctype2rust(arg) for arg in prototype.args
        ]
        returnty: RustSimType | None = (
            translator.ctype2rust(prototype.returnty) if prototype.returnty is not None else None
        )  # pyright: ignore[reportAssignmentType]
        return RustSimTypeFunction(args, returnty, prototype.label, prototype.arg_names, prototype.variadic)

    def _analyze(self):
        self._variables_in_use = {}

        # memo
        self.ailexpr2cnode = {}

        prototype = self._func.prototype

        if self._func_args:
            arg_list = [self._variable(arg, None) for arg in self._func_args]
            if isinstance(prototype, RustSimTypeFunction) and prototype.is_arg0_retbuf:
                arg_list = arg_list[1:]
        else:
            arg_list = []

        obj = self._handle(self._sequence)

        self.cnode2ailexpr = {v: k[0] for k, v in self.ailexpr2cnode.items()}

        self.rust_func = RustFunction(
            self._func.addr,
            self._func.name,
            prototype.normalize() if isinstance(prototype, RustSimTypeFunction) else prototype,
            arg_list,
            obj,
            self._variables_in_use,
            self.kb.dec_variables[self._func.addr],
            demangled_name=self._func.demangled_name,
            show_demangled_name=self.show_demangled_name,
            codegen=self,
        )
        self.rust_func = FieldReferenceCleanup.handle(self.rust_func)
        self.rust_func = PointerArithmeticFixer.handle(self.rust_func)
        self.rust_func = MakeTypecastsImplicit.handle(self.rust_func)

        # TODO store extern fallback size somewhere lol
        self.cexterns = {
            self._variable(v, 1)
            for v in self.externs
            if v not in self._inlined_strings and v not in self._function_pointers
        }

        self.regenerate_text()

    def cleanup(self):
        """
        Remove existing rendering results.
        """
        self.map_pos_to_node = None
        self.map_pos_to_addr = None
        self.map_addr_to_pos = None
        self.map_ast_to_pos = None
        self.text = None

    def regenerate_text(self) -> None:
        """
        Re-render text and re-generate all sorts of mapping information.
        """
        self.cleanup()
        if self.rust_func is None:
            return
        (
            self.text,
            self.map_pos_to_node,
            self.map_pos_to_addr,
            self.map_addr_to_pos,
            self.map_ast_to_pos,
        ) = self.render_text(self.rust_func)

    RENDER_TYPE = tuple[str, PositionMapping, PositionMapping, InstructionMapping, dict[Any, set[Any]]]

    def render_text(self, rust_func: RustFunction) -> RENDER_TYPE:
        pos_to_node = PositionMapping()
        pos_to_addr = PositionMapping()
        addr_to_pos = InstructionMapping()
        ast_to_pos = defaultdict(set)

        text = rust_func.c_repr(
            indent=self._indent, pos_to_node=pos_to_node, pos_to_addr=pos_to_addr, addr_to_pos=addr_to_pos
        )

        if self.display_notes:
            notes = self.render_notes()
            pos_to_node, pos_to_addr, addr_to_pos = self.adjust_mapping_positions(
                len(notes), pos_to_node, pos_to_addr, addr_to_pos
            )
            text = notes + text

        for elem, node in pos_to_node.items():
            if isinstance(node.obj, RustConstant):
                ast_to_pos[node.obj.value].add(elem)
            elif isinstance(node.obj, RustVariable):
                if node.obj.unified_variable is not None:
                    ast_to_pos[node.obj.unified_variable].add(elem)
                else:
                    ast_to_pos[node.obj.variable].add(elem)
            elif isinstance(node.obj, SimType):
                ast_to_pos[node.obj].add(elem)
            elif isinstance(node.obj, RustFunctionCall):
                if node.obj.callee_func is not None:
                    ast_to_pos[node.obj.callee_func].add(elem)
                else:
                    ast_to_pos[node.obj.callee_target].add(elem)
            elif isinstance(node.obj, RustStructField):
                key = (node.obj.struct_type, node.obj.offset)
                ast_to_pos[key].add(elem)
            else:
                ast_to_pos[node.obj].add(elem)

        return text, pos_to_node, pos_to_addr, addr_to_pos, ast_to_pos

    def render_notes(self) -> str:
        """
        Render decompilation notes.

        :return: A string containing all notes.
        """
        if not self.notes:
            return ""

        lines = []
        for note in self.notes.values():
            note_lines = str(note).split("\n")
            lines += [f"// {line}" for line in note_lines]
        return "\n".join(lines) + "\n\n"

    def _get_variable_type(self, var, is_global=False):
        if is_global:
            return self.kb.dec_variables["global"].get_variable_type(var)
        return self.kb.dec_variables[self._func.addr].get_variable_type(var)

    def _get_derefed_type(self, ty: SimType) -> SimType | None:
        if ty is None:
            return None
        ty = unpack_typeref(ty)
        if isinstance(ty, RustSimTypeReference):
            return unpack_typeref(ty.pts_to).with_arch(self.project.arch)
        if isinstance(ty, SimTypeArray):
            return unpack_typeref(ty.elem_type).with_arch(self.project.arch)
        return ty

    def reload_variable_types(self) -> None:
        if self._variables_in_use is not None:
            for var in self._variables_in_use.values():
                if isinstance(var, RustVariable):
                    new_type = self._get_variable_type(
                        var.variable,
                        is_global=isinstance(var.variable, SimMemoryVariable)
                        and not isinstance(var.variable, SimStackVariable),
                    )
                    if new_type is not None:
                        var.variable_type = new_type

        if self.cexterns is not None:
            for var in self.cexterns:
                if isinstance(var, RustVariable):
                    new_type = self._get_variable_type(var.variable, is_global=True)
                    if new_type is not None:
                        var.variable_type = new_type

    #
    # Util methods
    #

    def default_simtype_from_size(self, n: int, signed: bool = True) -> RustSimTypeInt:
        return RustSimTypeInt(size=n * self.project.arch.byte_width, signed=signed).with_arch(self.project.arch)

    def _variable(self, variable: SimVariable, fallback_type_size: int | None) -> RustVariable:
        # TODO: we need to fucking make sure that variable recovery and type inference actually generates a size
        # TODO: for each variable it links into the fucking ail. then we can remove fallback_type_size.
        # if "c8" in str(variable):
        #     import ipdb
        #
        #     ipdb.set_trace()
        unified = self.kb.dec_variables[self._func.addr].unified_variable(variable)
        variable_type = self._get_variable_type(
            variable, is_global=isinstance(variable, SimMemoryVariable) and not isinstance(variable, SimStackVariable)
        )
        if variable_type is None:
            variable_type = self.default_simtype_from_size(fallback_type_size or self.project.arch.bytes)
        cvar = RustVariable(variable, unified_variable=unified, variable_type=variable_type, codegen=self)
        if self._variables_in_use is not None:
            self._variables_in_use[variable] = cvar
        return cvar

    def _get_variable_reference(self, cvar: RustVariable) -> RustExpression:
        """
        Return a reference to a CVariable instance with special handling of arrays and array pointers.

        :param cvar:    The CVariable object.
        :return:        A reference to a CVariable object.
        """

        if isinstance(cvar.type, (SimTypeArray, SimTypeFixedSizeArray)):
            return cvar
        if isinstance(cvar.type, RustSimTypeReference) and isinstance(
            cvar.type.pts_to, (SimTypeArray, SimTypeFixedSizeArray)
        ):
            return cvar
        return RustUnaryOp("Reference", cvar, codegen=self)

    def _access_reference(self, expr: RustExpression, data_type: SimType) -> RustExpression:
        result = self._access(expr, data_type, True)
        if isinstance(result, RustUnaryOp) and result.op == "Dereference":
            result = result.operand
        else:
            result = RustUnaryOp("Reference", result, codegen=self)
        return result

    def _access_constant_offset_reference(
        self, expr: RustExpression, offset: int, data_type: SimType | None
    ) -> RustExpression:
        result = self._access_constant_offset(expr, offset, data_type or SimTypeBottom(), True)
        if isinstance(result, RustTypeCast) and data_type is None:
            result = result.expr
        if isinstance(result, RustUnaryOp) and result.op == "Dereference":
            result = result.operand
            if isinstance(result, RustTypeCast) and data_type is None:
                result = result.expr
        else:
            result = RustUnaryOp("Reference", result, codegen=self)
        return result

    def _access_constant_offset(
        self,
        expr: RustExpression,
        offset: int,
        data_type: SimType,
        lvalue: bool,
        renegotiate_type: Callable[[SimType, SimType], SimType] = lambda old, proposed: old,
    ) -> RustExpression:
        def _force_type_cast(src_type_: SimType, dst_type_: SimType, expr_: RustExpression) -> RustUnaryOp:
            src_type_ptr = RustSimTypeReference(src_type_).with_arch(self.project.arch)
            dst_type_ptr = RustSimTypeReference(dst_type_).with_arch(self.project.arch)
            return RustUnaryOp(
                "Dereference",
                RustTypeCast(
                    src_type_ptr,
                    dst_type_ptr,
                    RustUnaryOp("Reference", expr_, codegen=self),
                    codegen=self,
                ),
                codegen=self,
            )

        # expr must express a POINTER to the base
        # returns a value which has a simtype of data_type as if it were dereferenced out of expr
        data_type = unpack_typeref(data_type)
        base_type = unpack_typeref(unpack_pointer(expr.type))
        if base_type is None:
            # well, not much we can do
            if data_type is None:
                raise TypeError("RustStructuredCodeGenerator programming error: no type whatsoever for dereference")
            if offset:
                expr = RustBinaryOp("Add", expr, RustConstant(offset, RustSimTypeInt(), codegen=self), codegen=self)
            return RustUnaryOp(
                "Dereference",
                RustTypeCast(
                    expr.type, RustSimTypeReference(data_type).with_arch(self.project.arch), expr, codegen=self
                ),
                codegen=self,
            )

        base_expr = expr.operand if isinstance(expr, RustUnaryOp) and expr.op == "Reference" else None

        if offset == 0:
            data_type = renegotiate_type(data_type, base_type)
            if base_type == data_type or (
                not isinstance(base_type, SimTypeBottom)
                and not isinstance(data_type, SimTypeBottom)
                and (base_type.size or 0) < (data_type.size or 0)
            ):
                # case 1: we're done because we found it
                # case 2: we're done because we can never find it and we might as well stop early
                if base_expr:
                    if base_type != data_type:
                        return _force_type_cast(base_type, data_type, base_expr)
                    return base_expr

                if base_type != data_type:
                    return _force_type_cast(base_type, data_type, expr)
                return RustUnaryOp("Dereference", expr, codegen=self)

        stride = (
            1 if isinstance(base_type, SimTypeBottom) else (base_type.size or 0) // self.project.arch.byte_width or 1
        )
        index, remainder = divmod(offset, stride)
        if index != 0:
            index = RustConstant(index, RustSimTypeInt(), codegen=self)
            kernel = expr
            # create a CIndexedVariable indicating the index access
            if base_expr and isinstance(base_expr, RustIndexedVariable):
                old_index = base_expr.index
                kernel = base_expr.variable
                if not isinstance(old_index, RustConstant) or old_index.value != 0:
                    index = RustBinaryOp("Add", old_index, index, codegen=self)
            result = RustUnaryOp(
                "Reference", RustIndexedVariable(kernel, index, variable_type=base_type, codegen=self), codegen=self
            )
            return self._access_constant_offset(result, remainder, data_type, lvalue, renegotiate_type)

        if isinstance(base_type, SimStruct):
            # find the field that we're accessing
            field_name, field_offset = max(
                ((x, y) for x, y in base_type.offsets.items() if y <= remainder), key=lambda x: x[1]
            )
            field = RustStructField(base_type, field_offset, field_name, codegen=self)
            if base_expr:
                result = RustUnaryOp(
                    "Reference", RustVariableField(base_expr, field, False, codegen=self), codegen=self
                )
            else:
                result = RustUnaryOp("Reference", RustVariableField(expr, field, True, codegen=self), codegen=self)
            return self._access_constant_offset(result, remainder - field_offset, data_type, lvalue, renegotiate_type)

        if isinstance(base_type, (SimTypeFixedSizeArray, SimTypeArray)):
            result = base_expr or expr  # death to C
            if isinstance(result, RustIndexedVariable):
                # unpack indexed variable
                var = result.variable
                result = RustUnaryOp(
                    "Reference",
                    RustIndexedVariable(var, result.index, variable_type=base_type.elem_type, codegen=self),
                    codegen=self,
                )
            else:
                result = RustUnaryOp(
                    "Reference",
                    RustIndexedVariable(
                        result,
                        RustConstant(0, RustSimTypeInt(), codegen=self),
                        variable_type=base_type.elem_type,
                        codegen=self,
                    ),
                    codegen=self,
                )
            return self._access_constant_offset(result, remainder, data_type, lvalue, renegotiate_type)

        # TODO is it a big-endian downcast?
        # e.g. int x; *((char*)x + 3) is actually just (char)x

        if remainder != 0:
            # pointer cast time!
            # TODO: BYTE2() and other ida-isms if we're okay with an rvalue
            if stride != 1:
                expr = RustTypeCast(
                    expr.type, RustSimTypeReference(SimTypeChar()).with_arch(self.project.arch), expr, codegen=self
                )
            expr_with_offset = RustBinaryOp(
                "Add", expr, RustConstant(remainder, RustSimTypeInt(), codegen=self), codegen=self
            )
            return RustUnaryOp(
                "Dereference",
                RustTypeCast(
                    expr_with_offset.type,
                    RustSimTypeReference(data_type).with_arch(self.project.arch),
                    expr_with_offset,
                    codegen=self,
                ),
                codegen=self,
            )

        # the case where we don't need a cast is handled at the start
        # if we've requested the result be an lvalue we have to do a pointer cast
        # if the value is not a trivial reference we have to do a pointer cast (?)
        if lvalue or not base_expr:
            return RustUnaryOp(
                "Dereference",
                RustTypeCast(expr.type, RustSimTypeReference(data_type), expr, codegen=self),
                codegen=self,
            )
        # otherwise, normal cast
        return RustTypeCast(base_type, data_type, base_expr, codegen=self)

    def _access(
        self,
        expr: RustExpression,
        data_type: SimType,
        lvalue: bool,
        renegotiate_type: Callable[[SimType, SimType], SimType] = lambda old, proposed: old,
    ) -> RustExpression:
        # same rule as _access_constant_offset wrt pointer expressions
        data_type = unpack_typeref(data_type)
        base_type = unpack_pointer(expr.type)
        if base_type is None:
            # use the fallback from above
            return self._access_constant_offset(expr, 0, data_type, lvalue, renegotiate_type)

        o_constant, o_terms = extract_terms(expr)

        def bail_out():
            if len(o_terms) == 0:
                # probably a plain integer, return as is
                return expr
            result = None
            pointer_length_int_type = (
                RustSimTypeInt(size=64, signed=False)
                if self.project.arch.bits == 64
                else RustSimTypeInt(size=32, signed=False)
            )
            for c, t in o_terms:
                op = "Add"
                if c == -1 and result is not None:
                    op = "Sub"
                    piece = (
                        t
                        if not isinstance(t.type, RustSimTypeReference)
                        else RustTypeCast(
                            t.type, RustSimTypeReference(RustSimTypeInt(size=8, signed=False)), t, codegen=self
                        )
                    )
                elif c == 1:
                    piece = (
                        t
                        if not isinstance(t.type, RustSimTypeReference)
                        else RustTypeCast(
                            t.type, RustSimTypeReference(RustSimTypeInt(size=8, signed=False)), t, codegen=self
                        )
                    )
                else:
                    piece = RustBinaryOp(
                        "Mul",
                        RustConstant(c, t.type, codegen=self),
                        (
                            t
                            if not isinstance(t.type, RustSimTypeReference)
                            else RustTypeCast(t.type, pointer_length_int_type, t, codegen=self)
                        ),
                        codegen=self,
                    )
                result = piece if result is None else RustBinaryOp(op, result, piece, codegen=self)
            if o_constant != 0:
                result = RustBinaryOp(
                    "Add", RustConstant(o_constant, RustSimTypeInt(), codegen=self), result, codegen=self
                )

            assert result is not None
            return RustUnaryOp(
                "Dereference",
                RustTypeCast(result.type, RustSimTypeReference(data_type), result, codegen=self),
                codegen=self,
            )

        # pain.
        # step 1 is split expr into a sum of terms, each of which is a product of a constant stride and an index
        # also identify the "kernel", the root of the expression
        constant, terms = o_constant, list(o_terms)
        if constant < 0:
            constant = -constant  # TODO: This may not be correct. investigate later

        i = 0
        kernel = None
        while i < len(terms):
            c, t = terms[i]
            if isinstance(unpack_typeref(t.type), RustSimTypeReference):
                if kernel is not None:
                    l.warning("Summing two different pointers together. Uh oh!")
                    return bail_out()
                if c != 1:
                    l.warning("Multiplying a pointer by a constant??")
                    return bail_out()
                kernel = t
                terms.pop(i)
                continue
            i += 1

        if kernel is None:
            l.warning("Dereferencing a plain integer. Uh oh!")
            return bail_out()

        terms.sort(key=lambda x: x[0])

        # suffering.
        while terms:
            kernel_type = unpack_typeref(unpack_pointer(kernel.type))
            assert kernel_type

            if isinstance(kernel_type, SimTypeBottom):
                return bail_out()
            size = kernel_type.size or 0
            kernel_stride = size // self.project.arch.byte_width if size else 1

            # if the constant offset is larger than the current fucker, uh, do something about that first
            if constant >= kernel_stride:
                index, remainder = divmod(constant, kernel_stride)
                kernel = RustUnaryOp(
                    "Reference",
                    self._access_constant_offset(kernel, index * kernel_stride, kernel_type, True, renegotiate_type),
                    codegen=self,
                )
                constant = remainder
                continue

            # next, uh, check if there's an appropriately sized stride term that we can apply
            next_stride, next_term = terms[-1]
            if next_stride % kernel_stride == 0:
                index_multiplier = next_stride // kernel_stride
                if index_multiplier != 1:
                    index = RustBinaryOp(
                        "Mul", RustConstant(index_multiplier, RustSimTypeInt(), codegen=self), next_term, codegen=self
                    )
                else:
                    index = next_term
                if (
                    isinstance(kernel, RustUnaryOp)
                    and kernel.op == "Reference"
                    and isinstance(kernel.operand, RustIndexedVariable)
                ):
                    old_index = kernel.operand.index
                    kernel = kernel.operand.variable
                    if not isinstance(old_index, RustConstant) or old_index.value != 0:
                        index = RustBinaryOp("Add", old_index, index, codegen=self)
                kernel = RustUnaryOp("Reference", RustIndexedVariable(kernel, index, codegen=self), codegen=self)
                terms.pop()
                continue

            if next_stride > kernel_stride:
                l.warning("Oddly-sized array access stride. Uh oh!")
                return bail_out()

            # nothing has the ability to escape the kernel
            # go in deeper
            if isinstance(kernel_type, SimStruct):
                field_name, field_offset = max(
                    ((x, y) for x, y in kernel_type.offsets.items() if y <= constant), key=lambda x: x[1]
                )
                field_type = kernel_type.fields[field_name]
                kernel = RustUnaryOp(
                    "Reference",
                    self._access_constant_offset(kernel, field_offset, field_type, True, renegotiate_type),
                    codegen=self,
                )
                constant -= field_offset
                continue

            if isinstance(kernel_type, (SimTypeArray, SimTypeFixedSizeArray)):
                inner = self._access_constant_offset(kernel, 0, kernel_type.elem_type, True, renegotiate_type)
                if isinstance(inner, RustUnaryOp) and inner.op == "Dereference":
                    # unpack
                    kernel = inner.operand
                else:
                    kernel = RustUnaryOp("Reference", inner, codegen=self)
                if unpack_typeref(unpack_pointer(kernel.type)) == kernel_type:
                    # we are not making progress
                    pass
                else:
                    continue

            l.warning("There's a variable offset with stride shorter than the primitive type. What does this mean?")
            return bail_out()

        return self._access_constant_offset(kernel, constant, data_type, lvalue, renegotiate_type)

    #
    # Handlers
    #

    def _handle(self, node, is_expr: bool = True, lvalue: bool = False):
        # if (node, is_expr) in self.ailexpr2cnode:
        #     return self.ailexpr2cnode[(node, is_expr)]

        handler: Callable | None = self._handlers.get(_dispatch_key(node), None)
        if handler is not None:
            if isinstance(node, (Expr.Call, FunctionLikeMacro)):
                # special case for Call
                converted = handler(node, is_expr=is_expr)
            else:
                converted = handler(node, lvalue=lvalue)
            if self.ailexpr2cnode is not None:
                self.ailexpr2cnode[(node, is_expr)] = converted
            return converted
        raise UnsupportedNodeTypeError(
            f"Node type {getattr(node, 'kind', None) or type(node).__name__} is not supported yet."
        )

    def _handle_Code(self, node, **kwargs):
        return self._handle(node.node, is_expr=False)

    def _handle_Sequence(self, seq, **kwargs):
        lines = []

        for node in seq.nodes:
            lines.append(self._handle(node, is_expr=False))

        if not lines:
            return RustStatements([], codegen=None)

        return RustStatements(lines, codegen=self) if len(lines) > 1 else lines[0]

    def _handle_Loop(self, loop_node, **kwargs):
        tags = {"ins_addr": loop_node.addr}

        if loop_node.sort == "while":
            if loop_node.condition is None or (
                isinstance(loop_node.condition, ailment.Const) and loop_node.condition.value is True
            ):
                return RustInfiniteLoop(
                    None if loop_node.sequence_node is None else self._handle(loop_node.sequence_node, is_expr=False),
                    tags=tags,
                    codegen=self,
                )
            return RustWhileLoop(
                None if loop_node.condition is None else self._handle(loop_node.condition),
                None if loop_node.sequence_node is None else self._handle(loop_node.sequence_node, is_expr=False),
                tags=tags,
                codegen=self,
            )
        if loop_node.sort == "do-while":
            return RustDoWhileLoop(
                self._handle(loop_node.condition),
                None if loop_node.sequence_node is None else self._handle(loop_node.sequence_node, is_expr=False),
                tags=tags,
                codegen=self,
            )
        if loop_node.sort == "for":
            return RustForLoop(
                None if loop_node.initializer is None else self._handle(loop_node.initializer),
                None if loop_node.condition is None else self._handle(loop_node.condition),
                None if loop_node.iterator is None else self._handle(loop_node.iterator),
                None if loop_node.sequence_node is None else self._handle(loop_node.sequence_node, is_expr=False),
                tags=tags,
                codegen=self,
            )

        raise NotImplementedError

    def _handle_Condition(self, condition_node: ConditionNode, **kwargs):
        tags = {"ins_addr": condition_node.addr}

        condition_and_nodes = [
            (
                self._handle(condition_node.condition),
                self._handle(condition_node.true_node, is_expr=False) if condition_node.true_node else None,
            )
        ]

        else_node = self._handle(condition_node.false_node, is_expr=False) if condition_node.false_node else None

        return RustIfElse(
            condition_and_nodes,
            else_node=else_node,
            simplify_else_scope=self.simplify_else_scope
            and self.ail_graph is not None
            and structured_node_is_simple_return(condition_node.true_node, self.ail_graph)
            and else_node is not None,
            cstyle_ifs=self.cstyle_ifs,
            tags=tags,
            codegen=self,
        )

    def _handle_CascadingCondition(self, cond_node: CascadingConditionNode, **kwargs):
        tags = {"ins_addr": cond_node.addr}

        condition_and_nodes = [
            (self._handle(cond), self._handle(node, is_expr=False)) for cond, node in cond_node.condition_and_nodes
        ]
        else_node = self._handle(cond_node.else_node) if cond_node.else_node is not None else None

        return RustIfElse(
            condition_and_nodes,
            else_node=else_node,
            tags=tags,
            cstyle_ifs=self.cstyle_ifs,
            codegen=self,
        )

    def _handle_ConditionalBreak(self, node, **kwargs):
        tags = {"ins_addr": node.addr}

        return RustIfBreak(self._handle(node.condition), cstyle_ifs=self.cstyle_ifs, tags=tags, codegen=self)

    def _handle_Break(self, node, **kwargs):
        tags = {"ins_addr": node.addr}

        return RustBreak(tags=tags, codegen=self)

    def _handle_MultiNode(self, node, **kwargs):
        lines = []

        for n in node.nodes:
            r = self._handle(n, is_expr=False)
            lines.append(r)

        return RustStatements(lines, codegen=self) if len(lines) > 1 else lines[0]

    def _handle_SwitchCase(self, node, **kwargs):
        """

        :param SwitchCaseNode node:
        :return:
        """

        switch_expr = self._handle(node.switch_expr)
        cases = [(idx, self._handle(case, is_expr=False)) for idx, case in node.cases.items()]
        default = self._handle(node.default_node, is_expr=False) if node.default_node is not None else None
        tags = {"ins_addr": node.addr}
        return RustSwitchCase(switch_expr, cases, default=default, tags=tags, codegen=self)

    def _handle_IncompleteSwitchCase(self, node: IncompleteSwitchCaseNode, **kwargs):
        head = self._handle(node.head, is_expr=False)
        cases = [(case.addr, self._handle(case, is_expr=False)) for case in node.cases]
        return RustIncompleteSwitchCase(head, cases, tags={"ins_addr": node.addr}, codegen=self)

    def _get_bound_variable(self, move):
        expr = None
        var = None
        if isinstance(move, ailment.Stmt.Store):
            expr = move.addr
            var = self._variable_map.variable(move)
        elif isinstance(move, ailment.Stmt.Assignment):
            expr = move.dst
            var = self._variable_map.variable(move.dst)
        if expr and var is not None:
            var_thing = self._variable(var, expr.size)
            var_thing.tags = dict(expr.tags)
            if "def_at" in var_thing.tags and "ins_addr" not in var_thing.tags:
                def_at = var_thing.tags["def_at"]
                var_thing.tags["ins_addr"] = getattr(def_at, "ins_addr", None)
            return var_thing
        return None

    def _handle_PatternMatch(self, node, **kwargs):
        scrutinee = self._handle(node.scrutinee)
        arms = [
            (
                (variant_and_moves[0], tuple(self._get_bound_variable(move) for move in variant_and_moves[1])),
                self._handle(arm, is_expr=False),
            )
            for variant_and_moves, arm in node.arms.items()
        ]
        default = self._handle(node.default_node, is_expr=False) if node.default_node is not None else None
        tags = {"ins_addr": node.addr}
        return RustPatternMatch(scrutinee, arms, default=default, tags=tags, codegen=self)

    def _handle_IfLet(self, node, **kwargs):
        variant_and_moves = node.pattern
        pattern = (variant_and_moves[0], tuple(self._get_bound_variable(move) for move in variant_and_moves[1]))
        scrutinee = self._handle(node.scrutinee)
        true_node = self._handle(node.true_node, is_expr=False)
        false_node = self._handle(node.false_node, is_expr=False) if node.false_node is not None else None
        tags = {"ins_addr": node.addr}
        return RustIfLet(pattern, scrutinee, true_node, false_node, tags=tags, codegen=self)

    def _handle_Continue(self, node, **kwargs):
        tags = {"ins_addr": node.addr}

        return RustContinue(tags=tags, codegen=self)

    def _handle_AILBlock(self, node, **kwargs):
        """

        :param Block node:
        :return:
        """

        # return CStatements([ CAILBlock(node) ])
        cstmts = []
        for stmt in node.statements:
            try:
                cstmt = self._handle(stmt, is_expr=False)
            except UnsupportedNodeTypeError:
                l.warning(
                    "Unsupported AIL statement or expression %s.",
                    getattr(stmt, "kind", None) or type(stmt).__name__,
                    exc_info=True,
                )
                cstmt = RustUnsupportedStatement(stmt, codegen=self)
            cstmts.append(cstmt)

        return RustStatements(cstmts, codegen=self)

    #
    # AIL statement handlers
    #

    def _handle_Stmt_Store(self, stmt: Stmt.Store, **kwargs):
        cdata = self._handle(stmt.data)

        store_bits = stmt.size * self.project.arch.byte_width
        if cdata.type is None or cdata.type.size != store_bits:
            if cdata.type is not None and cdata.type.size is not None:
                l.error(
                    "Store data lifted to a type of a different size: %s is %d bits, the store is %d bits. "
                    "Using the store width.",
                    cdata.type,
                    cdata.type.size,
                    store_bits,
                )
            if cdata.type is None or qualifies_for_width_cast(unpack_typeref(cdata.type)):
                # an untyped or mis-sized scalar must still write stmt.size bytes: retype the value at the
                # store width so _access renders the access at that width instead of the inferred one.
                cdata = RustTypeCast(
                    cdata.type,
                    self.default_simtype_from_size(stmt.size, signed=getattr(cdata.type, "signed", False)),
                    cdata,
                    codegen=self,
                )

        def negotiate(old_ty, proposed_ty):
            # transfer casts from the dst to the src if possible
            # if we see something like *(size_t*)&v4 = x; where v4 is a pointer, change to v4 = (void*)x;
            nonlocal cdata
            if old_ty != proposed_ty and qualifies_for_simple_cast(old_ty, proposed_ty):
                cdata = RustTypeCast(cdata.type, proposed_ty, cdata, codegen=self)
                return proposed_ty
            return old_ty

        stmt_var = self._variable_map.variable(stmt)
        if stmt_var is not None:
            cvar = self._variable(stmt_var, stmt.size)
            offset = self._variable_map.variable_offset(stmt) or 0
            assert type(offset) is int  # I refuse to deal with the alternative
            cdst = self._access_constant_offset(self._get_variable_reference(cvar), offset, cdata.type, True, negotiate)
        else:
            addr_expr = self._handle(stmt.addr)
            cdst = self._access(addr_expr, cdata.type, True, negotiate)

        return RustAssignment(cdst, cdata, tags=stmt.tags, codegen=self)

    def _handle_Stmt_Assignment(self, stmt, **kwargs):
        cdst = self._handle(stmt.dst, lvalue=True)
        csrc = self._handle(stmt.src, lvalue=False)

        return RustAssignment(cdst, csrc, tags=stmt.tags, codegen=self)

    def _handle_Stmt_SideEffectStatement(self, stmt: Stmt.SideEffectStatement, is_expr: bool = False, **kwargs):
        if isinstance(stmt.expr, FunctionLikeMacro):
            macro = self._handle_FunctionLikeMacro(stmt.expr, is_expr=is_expr or stmt.ret_expr is not None)
            if not is_expr and stmt.ret_expr is not None:
                ret_expr = self._handle(stmt.ret_expr)
                if isinstance(ret_expr, RustUnaryOp) and ret_expr.op == "Reference":
                    ret_expr = ret_expr.operand
                return RustAssignment(ret_expr, macro, tags=stmt.tags, codegen=self)
            return macro

        try:
            # Try to handle it as a normal function call
            target = self._handle(stmt.expr.target) if not isinstance(stmt.expr.target, str) else stmt.expr.target
        except UnsupportedNodeTypeError:
            target = stmt.expr.target

        target_func = self.kb.functions.function(addr=target.value) if isinstance(target, RustConstant) else None

        args = []
        if stmt.expr.args is not None:
            for i, arg in enumerate(stmt.expr.args):
                type_ = None
                if (
                    target_func is not None
                    and target_func.prototype is not None
                    and i < len(target_func.prototype.args)
                ):
                    type_ = target_func.prototype.args[i].with_arch(self.project.arch)

                if isinstance(arg, Expr.Const):
                    if type_ is None or is_machine_word_size_type(type_, self.project.arch):
                        type_ = guess_value_type(arg.value, self.project) or type_

                    new_arg = self._handle_Expr_Const(arg, type_=type_)
                else:
                    new_arg = self._handle(arg)
                args.append(new_arg)

        ret_expr = None
        if not is_expr and stmt.ret_expr is not None:
            ret_expr = self._handle(stmt.ret_expr)
            if isinstance(ret_expr, RustUnaryOp) and ret_expr.op == "Reference":
                ret_expr = ret_expr.operand

        result = RustFunctionCall(
            target,
            target_func,
            args,
            returning=bool(target_func.returning) if target_func is not None else True,
            ret_expr=ret_expr,
            receiver=self._handle(stmt.tags["receiver"]) if "receiver" in stmt.tags else None,
            tags=stmt.tags,
            is_expr=is_expr,
            show_demangled_name=self.show_demangled_name,
            callsite_prototype=self._variable_map.prototype(stmt.expr),  # pyright: ignore[reportArgumentType]
            codegen=self,
        )

        if result.is_expr and result.type.size != stmt.size * self.project.arch.byte_width:
            result = RustTypeCast(
                result.type,
                self.default_simtype_from_size(stmt.size, signed=getattr(result.type, "signed", False)),
                result,
                codegen=self,
            )

        return result

    def _handle_Stmt_Jump(self, stmt: Stmt.Jump, **kwargs):
        return RustGoto(self._handle(stmt.target), stmt.target_idx, tags=stmt.tags, codegen=self)

    def _handle_Stmt_ConditionalJump(self, stmt: Stmt.ConditionalJump, **kwargs):
        else_node = (
            None
            if stmt.false_target is None
            else RustGoto(self._handle(stmt.false_target), None, tags=stmt.tags, codegen=self)
        )
        return RustIfElse(
            [
                (
                    self._handle(stmt.condition),
                    RustGoto(self._handle(stmt.true_target), None, tags=stmt.tags, codegen=self),
                )
            ],
            else_node=else_node,
            cstyle_ifs=self.cstyle_ifs,
            tags=stmt.tags,
            codegen=self,
        )

    def _handle_Stmt_Return(self, stmt: Stmt.Return, **kwargs):
        if not stmt.ret_exprs:
            return RustReturn(None, tags=stmt.tags, codegen=self)
        if len(stmt.ret_exprs) == 1:
            ret_expr = stmt.ret_exprs[0]
            return RustReturn(self._handle(ret_expr), tags=stmt.tags, codegen=self)
        # TODO: Multiple return expressions
        l.warning("StructuredCodeGen does not support multiple return expressions yet. Only picking the first one.")
        ret_expr = stmt.ret_exprs[0]
        return RustReturn(self._handle(ret_expr), tags=stmt.tags, codegen=self)

    def _handle_Stmt_Label(self, stmt: Stmt.Label, **kwargs):
        ins_addr = stmt.tags.get("ins_addr")
        block_idx = stmt.tags.get("block_idx")
        clabel = RustLabel(stmt.name, ins_addr, block_idx, tags=stmt.tags, codegen=self)
        self.map_addr_to_label[(ins_addr, block_idx)] = clabel
        return clabel

    def _handle_Stmt_Dirty(self, stmt: Stmt.DirtyStatement, **kwargs):
        return RustDirtyStatement(self._handle(stmt.dirty), codegen=self)

    def _handle_Stmt_IncompleteSwitchCaseHead(self, stmt: IncompleteSwitchCaseHeadStatement, **kwargs):
        # render the dispatch as a cascade of if-gotos rather than dropping every target
        switch_var = self._handle(stmt.switch_variable)
        bits = getattr(stmt.switch_variable, "bits", None) or self.project.arch.bits
        const_type = RustSimTypeInt(size=bits, signed=False).with_arch(self.project.arch)
        condition_and_nodes = []
        default_goto = None
        for _, case_value, target_addr, target_idx, _ in stmt.case_addrs:
            goto = RustGoto(target_addr, target_idx, tags=stmt.tags, codegen=self)
            if isinstance(case_value, str):
                if case_value == "default":
                    default_goto = goto
                continue
            cond = RustBinaryOp(
                "CmpEQ",
                switch_var,
                RustConstant(case_value, const_type, tags=stmt.tags, codegen=self),
                codegen=self,
                tags=stmt.tags,
            )
            condition_and_nodes.append((cond, goto))
        if not condition_and_nodes:
            return default_goto if default_goto is not None else RustUnsupportedStatement(stmt, codegen=self)
        return RustIfElse(condition_and_nodes, else_node=default_goto, tags=stmt.tags, codegen=self)

    def _handle_Stmt_CAS(self, stmt: Stmt.CAS, **kwargs):
        # render whatever CASIntrinsics did not rewrite as the same intrinsic call
        if stmt.old_hi is None:
            os_name = self.project.simos.name if self.project.simos is not None else None
            call = Expr.Call(
                stmt.idx,
                cas_intrinsic_name(f"cmpxchg{stmt.bits}", os_name),
                args=[stmt.addr, stmt.data_lo, stmt.expd_lo],
                bits=stmt.bits,
                **stmt.tags,
            )
            return self._handle(Stmt.Assignment(stmt.idx, stmt.old_lo, call, **stmt.tags), is_expr=False)
        # a double-width CAS writes two destinations, which no single expression captures
        return RustUnsupportedStatement(stmt, codegen=self)

    #
    # AIL expression handlers
    #

    def _handle_Expr_Register(self, expr: Expr.Register, lvalue: bool = False, **kwargs):
        def negotiate(old_ty: SimType, proposed_ty: SimType) -> SimType:
            if old_ty.size == proposed_ty.size:  # noqa: SIM102
                # we do not allow returning a struct for a primitive type
                if not (isinstance(proposed_ty, SimStruct) and not isinstance(old_ty, SimStruct)):
                    return proposed_ty
            return old_ty

        expr_var = self._variable_map.variable(expr)
        if expr_var:
            cvar = self._variable(expr_var, None)
            if expr_var.size == expr.size:
                return cvar
            expr_var_offset = self._variable_map.variable_offset(expr)
            offset = 0 if expr_var_offset is None else expr_var_offset
            # FIXME: The type should be associated to the register expression itself
            type_ = self.default_simtype_from_size(expr.size, signed=False)
            return self._access_constant_offset(self._get_variable_reference(cvar), offset, type_, lvalue, negotiate)
        return RustRegister(expr, tags=expr.tags, codegen=self)

    def _handle_Expr_Load(self, expr: Expr.Load, **kwargs):
        ty = self.default_simtype_from_size(expr.size)

        def negotiate(old_ty: SimType, proposed_ty: SimType) -> SimType:
            if old_ty.size == proposed_ty.size:  # noqa: SIM102
                # we do not allow returning a struct for a primitive type
                if not (isinstance(proposed_ty, SimStruct) and not isinstance(old_ty, SimStruct)):
                    return proposed_ty
            return old_ty

        expr_var = self._variable_map.variable(expr)
        if expr_var is not None:
            cvar = self._variable(expr_var, expr.size)
            offset = self._variable_map.variable_offset(expr) or 0
            assert type(offset) is int  # I refuse to deal with the alternative
            return self._access_constant_offset(
                RustUnaryOp("Reference", cvar, codegen=self), offset, ty, False, negotiate
            )

        addr_expr = self._handle(expr.addr)
        return self._access(addr_expr, ty, False, negotiate)

    def _handle_Expr_Tmp(self, expr: Tmp, **kwargs):
        l.warning("FIXME: Leftover Tmp expressions are found.")
        return self._variable(SimTemporaryVariable(expr.tmp_idx, expr.size), expr.size)

    def _handle_Expr_Const(self, expr, type_=None, reference_values=None, variable=None, **kwargs):
        inline_string = False
        function_pointer = False

        if type_ is None and "type" in expr.tags:
            type_ = expr.tags["type"]

        if reference_values is None:
            reference_values = {}
            type_ = unpack_typeref(type_)
            if isinstance(type_, RustSimTypeReference) and isinstance(type_.pts_to, SimTypeChar):
                # char*
                # Try to get a string
                if (
                    self._cfg is not None
                    and expr.value in self._cfg.memory_data
                    and self._cfg.memory_data[expr.value].sort == MemoryDataSort.String
                ):
                    reference_values[type_] = self._cfg.memory_data[expr.value]
                    inline_string = True
            elif isinstance(type_, RustSimTypeInt):
                # int
                reference_values[type_] = expr.value

            # we don't know the type of this argument, or the type is not what we are expecting
            # edge cases: (void*)"this is a constant string pointer". in this case, the type_ will be a void*
            # (BOT*) instead of a char*.

            if isinstance(expr.value, int):
                if expr.value in self.project.kb.functions:
                    # It's a function pointer
                    # We don't care about the actual prototype here
                    type_ = RustSimTypeReference(SimTypeBottom(label="void")).with_arch(self.project.arch)
                    reference_values[type_] = self.project.kb.functions[expr.value]
                    function_pointer = True

                elif (section := self.project.loader.find_section_containing(expr.value)) and section.is_readable:
                    memory = self.project.loader.memory
                    str_addr = memory.unpack(expr.value, self.project.arch.struct_fmt())[0]
                    if (
                        (section := self.project.loader.find_section_containing(str_addr))
                        and section.is_readable
                        and not section.is_writable
                    ):
                        str_len = memory.unpack(expr.value + self.project.arch.bytes, self.project.arch.struct_fmt())[0]
                        try:
                            decoded_str = memory.load(str_addr, str_len).decode("utf-8")
                            type_ = RustSimTypeStrRef()
                            reference_values[type_] = decoded_str
                            inline_string = True
                        except UnicodeDecodeError:
                            pass
                    # If we failed to extract UTF-8 characters, it might be an empty string
                    if not inline_string and isinstance(type_, RustSimTypeStrRef):
                        decoded_str = ""
                        reference_values[type_] = decoded_str
                        inline_string = True

                # pure guessing: is it possible that it's a string?
                elif (
                    self._cfg is not None
                    and expr.bits == self.project.arch.bits
                    and expr.value > 0x10000
                    and expr.value in self._cfg.memory_data
                ):
                    md = self._cfg.memory_data[expr.value]
                    if md.sort == MemoryDataSort.String:
                        type_ = RustSimTypeReference(SimTypeChar().with_arch(self.project.arch)).with_arch(
                            self.project.arch
                        )
                        reference_values[type_] = self._cfg.memory_data[expr.value]
                        # is it a constant string?
                        if is_in_readonly_segment(self.project, expr.value) or is_in_readonly_section(
                            self.project, expr.value
                        ):
                            inline_string = True
                    elif md.sort == MemoryDataSort.UnicodeString:
                        type_ = RustSimTypeReference(SimTypeWideChar().with_arch(self.project.arch)).with_arch(
                            self.project.arch
                        )
                        reference_values[type_] = self._cfg.memory_data[expr.value]
                        # is it a constant string?
                        if is_in_readonly_segment(self.project, expr.value) or is_in_readonly_section(
                            self.project, expr.value
                        ):
                            inline_string = True

        if type_ is None:
            # default to int
            type_ = self.default_simtype_from_size(expr.size)

        expr_reference_variable = self._variable_map.reference_variable(expr)
        if variable is None and expr_reference_variable is not None:
            variable = expr_reference_variable
            if inline_string:
                self._inlined_strings.add(expr_reference_variable)
            elif function_pointer:
                self._function_pointers.add(expr_reference_variable)

        if variable is not None and not reference_values:
            cvar = self._variable(variable, None)
            offset = self._variable_map.reference_variable_offset(expr)
            return self._access_constant_offset_reference(self._get_variable_reference(cvar), offset, None)

        return RustConstant(expr.value, type_, reference_values=reference_values, tags=expr.tags, codegen=self)

    def _handle_FunctionLikeMacro(self, expr: FunctionLikeMacro, is_expr, **kwargs):
        return RustFunctionLikeMacro(
            expr.name,
            expr.args,
            expr.delimiter,
            is_expr=is_expr,
            returnty=self._variable_map.returnty(expr),
            tags=expr.tags,
            codegen=self,
        )

    def _handle_Expr_Call(self, expr: Expr.Call, is_expr: bool = False, **kwargs):
        """Handle calls that are not wrapped within a SideEffectStatement."""

        try:
            # Try to handle it as a normal function call
            target = self._handle(expr.target) if not isinstance(expr.target, str) else expr.target
        except UnsupportedNodeTypeError:
            target = expr.target

        target_func = self.kb.functions.function(addr=target.value) if isinstance(target, RustConstant) else None

        args = []
        if expr.args is not None:
            for i, arg in enumerate(expr.args):
                type_ = None
                if (
                    target_func is not None
                    and target_func.prototype is not None
                    and i < len(target_func.prototype.args)
                ):
                    type_ = target_func.prototype.args[i].with_arch(self.project.arch)

                if isinstance(arg, Expr.Const):
                    if type_ is None or is_machine_word_size_type(type_, self.project.arch):
                        type_ = guess_value_type(arg.value, self.project) or type_

                    new_arg = self._handle_Expr_Const(arg, type_=type_)
                else:
                    new_arg = self._handle(arg)
                args.append(new_arg)

        ret_expr = None

        result = RustFunctionCall(
            target,
            target_func,
            args,
            returning=bool(target_func.returning) if target_func is not None else True,
            ret_expr=ret_expr,
            receiver=self._handle(expr.tags["receiver"]) if "receiver" in expr.tags else None,
            tags=expr.tags,
            is_expr=is_expr,
            show_demangled_name=self.show_demangled_name,
            callsite_prototype=self._variable_map.prototype(expr),  # pyright: ignore[reportArgumentType]
            codegen=self,
        )

        if result.is_expr and result.type.size != expr.size * self.project.arch.byte_width:
            result = RustTypeCast(
                result.type,
                self.default_simtype_from_size(expr.size, signed=getattr(result.type, "signed", False)),
                result,
                codegen=self,
            )

        return result

    def _handle_Expr_StringLiteral(self, expr: StringLiteral, **kwargs):
        return RustStringLiteral(expr.data, tags=expr.tags, codegen=self)

    def _handle_Expr_Extract(self, expr: Expr.Extract, **kwargs):
        base = self._handle(expr.base)
        try:
            base_type = base.type
        except NotImplementedError:
            base_type = None
        base_type = base_type or RustSimTypeInt(size=expr.base.bits, signed=False).with_arch(self.project.arch)
        base.set_type(base_type)

        target_type = RustSimTypeInt(size=expr.bits, signed=False).with_arch(self.project.arch)
        offset = (
            expr.offset.value if isinstance(expr.offset, Expr.Const) and isinstance(expr.offset.value, int) else None
        )

        if offset is not None:
            if expr.endness == archinfo.Endness.LE:
                shift_bits = offset * self.project.arch.byte_width
            else:
                shift_bits = expr.base.bits - expr.bits - offset * self.project.arch.byte_width

            shifted = base
            if shift_bits:
                shifted = RustBinaryOp(
                    "Shr",
                    base,
                    RustConstant(
                        shift_bits,
                        self.default_simtype_from_size(self.project.arch.bytes, signed=False),
                        codegen=self,
                    ),
                    tags=expr.tags,
                    codegen=self,
                )
            return RustTypeCast(base_type, target_type, shifted, tags=expr.tags, codegen=self)

        offset_expr = RustBinaryOp(
            "Mul",
            self._handle(expr.offset),
            RustConstant(
                self.project.arch.byte_width,
                self.default_simtype_from_size(self.project.arch.bytes, signed=False),
                codegen=self,
            ),
            tags=expr.tags,
            codegen=self,
        )
        if expr.endness == archinfo.Endness.LE:
            shift_expr = offset_expr
        else:
            shift_expr = RustBinaryOp(
                "Sub",
                RustConstant(
                    expr.base.bits - expr.bits,
                    self.default_simtype_from_size(self.project.arch.bytes, signed=False),
                    codegen=self,
                ),
                offset_expr,
                tags=expr.tags,
                codegen=self,
            )

        shifted = RustBinaryOp("Shr", base, shift_expr, tags=expr.tags, codegen=self)
        return RustTypeCast(base_type, target_type, shifted, tags=expr.tags, codegen=self)

    def _handle_Expr_Struct(self, expr: Struct, **kwargs):
        return RustStruct(
            expr.name,
            OrderedDict([(offset, self._handle(field)) for offset, field in expr.fields.items()]),
            expr.field_names,
            tags=expr.tags,
            codegen=self,
        )

    def _handle_Expr_RustEnum(self, expr: AilRustEnum, **kwargs):
        return RustEnum(
            expr.name,
            [self._handle(field) for field in expr.fields],
            tags=expr.tags,
            codegen=self,
        )

    def _handle_Expr_Array(self, expr: Array, **kwargs):
        return RustArray([self._handle(ele) for ele in expr.elements], tags=expr.tags, codegen=self)

    def _handle_Expr_Let(self, expr: Let, **kwargs):
        return RustLet(expr, tags=expr.tags, codegen=self)

    def _handle_Expr_UnaryOp(self, expr, **kwargs):
        return RustUnaryOp(
            expr.op,
            self._handle(expr.operand),
            tags=expr.tags,
            codegen=self,
        )

    def _handle_Expr_BinaryOp(self, expr: BinaryOp, **kwargs):
        expr_var = self._variable_map.variable(expr)
        if expr_var is not None:
            cvar = self._variable(expr_var, None)
            return self._access_constant_offset_reference(
                self._get_variable_reference(cvar), self._variable_map.variable_offset(expr) or 0, None
            )

        lhs = self._handle(expr.operands[0])
        rhs = self._handle(expr.operands[1])

        return RustBinaryOp(
            expr.op,
            lhs,
            rhs,
            tags=expr.tags,
            codegen=self,
            collapsed=expr.depth > self.binop_depth_cutoff,
        )

    def _handle_Expr_Convert(self, expr: Expr.Convert, **kwargs):
        # width of converted type is easy
        if 64 >= expr.to_bits > 32:
            dst_type: RustSimTypeInt | SimTypeChar = RustSimTypeInt(64)
        elif 32 >= expr.to_bits > 16:
            dst_type = RustSimTypeInt(32)
        elif 16 >= expr.to_bits > 8:
            dst_type = RustSimTypeInt(16)
        elif 8 >= expr.to_bits > 1:
            dst_type = RustSimTypeInt(8)
        elif expr.to_bits == 1:
            dst_type = SimTypeChar()  # FIXME: Add a SimTypeBit?
        else:
            dst_type = RustSimTypeInt(expr.to_bits)
            # raise UnsupportedNodeTypeError("Unsupported conversion bits %s." % expr.to_bits)

        # convert child
        child = self._handle(expr.operand)
        orig_child_signed = getattr(child.type, "signed", False)

        # signedness of converted type is hard
        if expr.to_bits < expr.from_bits:
            # very sketchy. basically a guess
            # can we even generate signed downcasts?
            dst_type.signed = orig_child_signed | expr.is_signed
        else:
            dst_type.signed = expr.is_signed

        # do we need an intermediate cast?
        if orig_child_signed != expr.is_signed and expr.to_bits > expr.from_bits:
            # this is a problem. sign-extension only happens when the SOURCE of the cast is signed
            child_ty = self.default_simtype_from_size(child.type.size // self.project.arch.byte_width, expr.is_signed)
            child = RustTypeCast(None, child_ty, child, codegen=self)

        return RustTypeCast(None, dst_type.with_arch(self.project.arch), child, tags=expr.tags, codegen=self)

    def _handle_Expr_VEXCCallExpression(self, expr: Expr.VEXCCallExpression, **kwargs):
        operands = [self._handle(arg) for arg in expr.operands]
        return RustVEXCCallExpression(expr.callee, operands, tags=expr.tags, codegen=self)

    def _handle_Expr_Dirty(self, expr, **kwargs):
        return RustDirtyExpression(expr, codegen=self)

    def _handle_Expr_Insert(self, expr: Expr.Insert, **kwargs):
        # should never really be used - should be handled by Assignment
        return RustFunctionCall(
            "_INSERT",
            None,
            [self._handle(expr.base), self._handle(expr.offset), self._handle(expr.value)],
            is_expr=True,
            tags=expr.tags,
            codegen=self,
        )

    def _handle_Expr_ITE(self, expr: Expr.ITE, **kwargs):
        return RustITE(
            self._handle(expr.cond), self._handle(expr.iftrue), self._handle(expr.iffalse), tags=expr.tags, codegen=self
        )

    def _handle_Reinterpret(self, expr: Expr.Reinterpret, **kwargs):
        def _to_type(bits, typestr):
            if typestr == "I":
                if bits == 32:
                    r = RustSimTypeInt()
                elif bits == 64:
                    r = SimTypeLongLong()
                else:
                    raise TypeError(f"Unsupported integer type with bits {bits} in Reinterpret")
            elif typestr == "F":
                if bits == 32:
                    r = SimTypeFloat()
                elif bits == 64:
                    r = SimTypeDouble()
                else:
                    raise TypeError(f"Unsupported floating-point type with bits {bits} in Reinterpret")
            else:
                raise TypeError(f"Unexpected reinterpret type {typestr}")
            return r.with_arch(self.project.arch)

        src_type = _to_type(expr.from_bits, expr.from_type)
        dst_type = _to_type(expr.to_bits, expr.to_type)
        return RustTypeCast(src_type, dst_type, self._handle(expr.operand), tags=expr.tags, codegen=self)

    def _handle_MultiStatementExpression(self, expr: Expr.MultiStatementExpression, **kwargs):
        cstmts = RustStatements([self._handle(stmt, is_expr=False) for stmt in expr.stmts], codegen=self)
        cexpr = self._handle(expr.expr)
        return RustMultiStatementExpression(cstmts, cexpr, tags=expr.tags, codegen=self)

    def _handle_VirtualVariable(self, expr: Expr.VirtualVariable, **kwargs):
        expr_var = self._variable_map.variable(expr)
        if expr_var:
            cvar = self._variable(expr_var, None)
            if expr_var.size != expr.size:
                l.warning(
                    "VirtualVariable size (%d) and variable size (%d) do not match. Force a type cast.",
                    expr.size,
                    expr_var.size,
                )
                src_type = cvar.type
                dst_type = RustSimTypeInt(expr.bits, signed=False)
                if dst_type is not None:
                    dst_type = dst_type.with_arch(self.project.arch)
                    return RustTypeCast(src_type, dst_type, cvar, tags=expr.tags, codegen=self)
            return cvar
        return RustDirtyExpression(expr, codegen=self)

    def _handle_Expr_StackBaseOffset(self, expr: StackBaseOffset, **kwargs):
        expr_var = self._variable_map.variable(expr)
        if expr_var is not None:
            var_thing = self._variable(expr_var, expr.size)
            var_thing.tags = dict(expr.tags)
            if "def_at" in var_thing.tags and "ins_addr" not in var_thing.tags:
                def_at = var_thing.tags["def_at"]
                var_thing.tags["ins_addr"] = getattr(def_at, "ins_addr", None)
            return self._get_variable_reference(var_thing)

        # FIXME
        stack_base = RustFakeVariable("stack_base", RustSimTypeReference(SimTypeBottom()), codegen=self)
        return RustBinaryOp("Add", stack_base, RustConstant(expr.offset, RustSimTypeInt(), codegen=self), codegen=self)


class RustStructuredCodeWalker:
    @classmethod
    def handle(cls, obj):
        handler = getattr(cls, "handle_" + type(obj).__name__, cls.handle_default)
        return handler(obj)

    @classmethod
    def handle_default(cls, obj):
        return obj

    @classmethod
    def handle_RustFunction(cls, obj):
        obj.statements = cls.handle(obj.statements)
        return obj

    @classmethod
    def handle_RustStatements(cls, obj):
        obj.statements = [cls.handle(stmt) for stmt in obj.statements]
        return obj

    @classmethod
    def handle_RustWhileLoop(cls, obj):
        obj.condition = cls.handle(obj.condition)
        obj.body = cls.handle(obj.body)
        return obj

    @classmethod
    def handle_RustInfiniteLoop(cls, obj):
        obj.body = cls.handle(obj.body)
        return obj

    @classmethod
    def handle_RustDoWhileLoop(cls, obj):
        obj.condition = cls.handle(obj.condition)
        obj.body = cls.handle(obj.body)
        return obj

    @classmethod
    def handle_RustForLoop(cls, obj):
        obj.initializer = cls.handle(obj.initializer)
        obj.condition = cls.handle(obj.condition)
        obj.iterator = cls.handle(obj.iterator)
        obj.body = cls.handle(obj.body)
        return obj

    @classmethod
    def handle_RustIfElse(cls, obj):
        obj.condition_and_nodes = [
            (cls.handle(condition), cls.handle(node)) for condition, node in obj.condition_and_nodes
        ]
        obj.else_node = cls.handle(obj.else_node)
        return obj

    @classmethod
    def handle_RustIfBreak(cls, obj):
        obj.condition = cls.handle(obj.condition)
        return obj

    @classmethod
    def handle_RustSwitchCase(cls, obj):
        obj.switch = cls.handle(obj.switch)
        obj.cases = [(case, cls.handle(body)) for case, body in obj.cases]
        obj.default = cls.handle(obj.default)
        return obj

    @classmethod
    def handle_RustAssignment(cls, obj):
        obj.lhs = cls.handle(obj.lhs)
        obj.rhs = cls.handle(obj.rhs)
        return obj

    @classmethod
    def handle_RustFunctionCall(cls, obj):
        obj.callee_target = cls.handle(obj.callee_target)
        obj.args = [cls.handle(arg) for arg in obj.args]
        obj.ret_expr = cls.handle(obj.ret_expr)
        return obj

    @classmethod
    def handle_RustReturn(cls, obj):
        obj.retval = cls.handle(obj.retval)
        return obj

    @classmethod
    def handle_RustGoto(cls, obj):
        obj.target = cls.handle(obj.target)
        return obj

    @classmethod
    def handle_RustIndexedVariable(cls, obj):
        obj.variable = cls.handle(obj.variable)
        obj.index = cls.handle(obj.index)
        return obj

    @classmethod
    def handle_RustVariableField(cls, obj):
        obj.variable = cls.handle(obj.variable)
        return obj

    @classmethod
    def handle_RustUnaryOp(cls, obj):
        obj.operand = cls.handle(obj.operand)
        return obj

    @classmethod
    def handle_RustBinaryOp(cls, obj):
        obj.lhs = cls.handle(obj.lhs)
        obj.rhs = cls.handle(obj.rhs)
        return obj

    @classmethod
    def handle_RustTypeCast(cls, obj):
        obj.expr = cls.handle(obj.expr)
        return obj

    @classmethod
    def handle_RustITE(cls, obj):
        obj.cond = cls.handle(obj.cond)
        obj.iftrue = cls.handle(obj.iftrue)
        obj.iffalse = cls.handle(obj.iffalse)
        return obj


class MakeTypecastsImplicit(RustStructuredCodeWalker):
    @classmethod
    def collapse(cls, dst_ty: SimType | None, child: RustExpression) -> RustExpression:
        result = child
        if isinstance(child, RustTypeCast):
            intermediate_ty = child.dst_type
            start_ty = child.src_type

            # step 1: collapse pointer-integer casts of the same size
            if qualifies_for_simple_cast(intermediate_ty, dst_ty) and qualifies_for_simple_cast(start_ty, dst_ty):
                result = child.expr
            # step 2: collapse integer conversions which are redundant
            if (
                isinstance(dst_ty, (SimTypeChar, RustSimTypeInt, SimTypeNum))
                and isinstance(intermediate_ty, (SimTypeChar, RustSimTypeInt, SimTypeNum))
                and isinstance(start_ty, (SimTypeChar, RustSimTypeInt, SimTypeNum))
            ):
                if (dst_ty.size or 0) <= (start_ty.size or 0) and (dst_ty.size or 0) <= (intermediate_ty.size or 0):
                    # this is a down- or neutral-cast with an intermediate step that doesn't matter
                    result = child.expr
                elif (dst_ty.size or 0) >= (intermediate_ty.size or 0) >= (
                    start_ty.size or 0
                ) and intermediate_ty.signed == start_ty.signed:
                    # this is an up- or neutral-cast which is monotonically ascending
                    # we can leave out the dst_ty.signed check
                    result = child.expr
                # more cases go here...

        if result is not child:
            # TODO this is not the best since it prohibits things like the BinaryOp optimizer from working incrementally
            return cls.collapse(dst_ty, result)
        return result

    @classmethod
    def handle_RustAssignment(cls, obj):
        obj.rhs = cls.collapse(obj.lhs.type, obj.rhs)
        return super().handle_RustAssignment(obj)

    @classmethod
    def handle_RustFunctionCall(cls, obj: RustFunctionCall):
        if obj.prototype is not None:
            for i, (c_arg, arg_ty) in enumerate(zip(obj.args, obj.prototype.args)):
                obj.args[i] = cls.collapse(arg_ty, c_arg)
        return super().handle_RustFunctionCall(obj)

    @classmethod
    def handle_RustReturn(cls, obj: RustReturn):
        prototype = obj.codegen._func.prototype
        if isinstance(prototype, RustSimTypeFunction):
            prototype = prototype.normalize()
        obj.retval = cls.collapse(prototype.returnty, obj.retval)
        return super().handle_RustReturn(obj)

    @classmethod
    def handle_RustBinaryOp(cls, obj: RustBinaryOp):
        obj = super().handle_RustBinaryOp(obj)
        while True:
            new_lhs = cls.collapse(obj.common_type, obj.lhs)
            if (
                new_lhs is not obj.lhs
                and RustBinaryOp.compute_common_type(obj.op, new_lhs.type, obj.rhs.type) == obj.common_type
            ):
                obj.lhs = new_lhs
            else:
                new_rhs = cls.collapse(obj.common_type, obj.rhs)
                if (
                    new_rhs is not obj.rhs
                    and RustBinaryOp.compute_common_type(obj.op, obj.lhs.type, new_rhs.type) == obj.common_type
                ):
                    obj.rhs = new_rhs
                else:
                    break
        return obj

    @classmethod
    def handle_RustTypeCast(cls, obj: RustTypeCast):
        # note that the expression that this method returns may no longer be a CTypeCast
        obj = super().handle_RustTypeCast(obj)
        inner = cls.collapse(obj.dst_type, obj.expr)
        if inner is not obj.expr:
            obj.src_type = inner.type
            obj.expr = inner

        if obj.src_type == obj.dst_type or qualifies_for_implicit_cast(obj.src_type, obj.dst_type):
            return obj.expr
        return obj


class FieldReferenceCleanup(RustStructuredCodeWalker):
    @classmethod
    def handle_RustTypeCast(cls, obj):
        if isinstance(obj.dst_type, RustSimTypeReference) and not isinstance(obj.dst_type.pts_to, SimTypeBottom):
            obj = obj.codegen._access_reference(obj.expr, obj.dst_type.pts_to)
            if not isinstance(obj, RustTypeCast):
                return cls.handle(obj)
        return super().handle_RustTypeCast(obj)


class PointerArithmeticFixer(RustStructuredCodeWalker):
    """
    Before calling this fixer class, pointer arithmetics are purely integer-based and ignoring the pointer type.

    For example, in the following case:

    struct A* a_ptr;  // assume struct A is 24 bytes in size
    a_ptr = a_ptr + 24;

    It means adding 24 to the address of a_ptr, without considering the size of struct A. This fixer class will make
    pointer arithmetics aware of the pointer type. In this case, the fixer class will convert the code to
    a_ptr = a_ptr + 1.
    """

    @classmethod
    def handle_RustBinaryOp(cls, obj: RustBinaryOp):
        obj = super().handle_RustBinaryOp(obj)
        if (
            obj.op in ("Add", "Sub")
            and isinstance(obj.type, RustSimTypeReference)
            and not isinstance(obj.type.pts_to, SimTypeBottom)
        ):
            out = obj.codegen._access_reference(obj, obj.type.pts_to)
            if (
                isinstance(out, RustUnaryOp)
                and out.op == "Reference"
                and isinstance(out.operand, RustIndexedVariable)
                and isinstance(out.operand.index, RustConstant)
            ):
                # rewrite &a[1] to a + 1
                const = out.operand.index
                if isinstance(const.value, int) and const.value < 0:
                    op = "Sub"
                    const = RustConstant(
                        -const.value,
                        const.type,
                        reference_values=const.reference_values,
                        tags=const.tags,
                        codegen=const.codegen,
                    )
                else:
                    op = "Add"
                return RustBinaryOp(op, out.operand.variable, const, out.operand.tags, codegen=out.codegen)
            return out
        return obj


register_analysis(RustStructuredCodeGenerator, "RustStructuredCodeGenerator")
