# pylint: disable=missing-class-docstring,no-self-use
from __future__ import annotations

from angr.ailment.expression import BinaryOp, Const, Convert, Insert

from .base import PeepholeOptimizationExprBase


class RemoveConstInsert(PeepholeOptimizationExprBase):
    __slots__ = ()

    NAME = "Insert(c0, c1, v) ==> (c0 & mask) | (v << c1)"
    expr_classes = (Insert,)

    def optimize(self, expr: Insert, **kwargs):
        if not (
            isinstance(expr.base, Const)
            and not expr.base.tags.get("uninitialized", False)
            and isinstance(expr.base.value, int)
            and isinstance(expr.offset, Const)
            and isinstance(expr.offset.value, int)
        ):
            return None

        # TODO fix big-endian?
        assert self.project is not None
        base = expr.base.value & ~((1 << expr.value.bits) - 1) << (expr.offset.value * self.project.arch.byte_width)
        value = Convert(self.manager.next_atom(), expr.value.bits, expr.bits, False, expr.value)
        shifted = (
            BinaryOp(
                self.manager.next_atom(),
                "Shl",
                [
                    value,
                    Const(self.manager.next_atom(), expr.offset.value * self.project.arch.byte_width, expr.bits),
                ],
                signed=False,
            )
            if expr.offset.value != 0
            else value
        )
        return BinaryOp(expr.idx, "Or", [shifted, Const(self.manager.next_atom(), base, shifted.bits)], signed=False)
