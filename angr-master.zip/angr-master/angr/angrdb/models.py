from __future__ import annotations

from sqlalchemy import BLOB, TEXT, Boolean, Column, Float, ForeignKey, Integer, String
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class DbInformation(Base):
    """
    Stores information related to the current database. Basically a key-value store.
    """

    __tablename__ = "information"

    id = Column(Integer, primary_key=True)
    key = Column(String, unique=True, index=True)
    value = Column(String)


class DbObject(Base):
    """
    Models a binary object.
    """

    __tablename__ = "objects"

    id = Column(Integer, primary_key=True)
    main_object = Column(Boolean, default=False)
    path = Column(String, default="", nullable=True)
    content = Column(BLOB, nullable=True)
    backend = Column(String)
    backend_args = Column(String, nullable=True)  # it's a JSON field but JSON is not supported in sqlite before 3.9


class DbKnowledgeBase(Base):
    """
    Models a knowledge base.
    """

    __tablename__ = "knowledgebases"

    id = Column(Integer, primary_key=True)
    name = Column(String, default="", nullable=True)

    cfgs = relationship("DbCFGModel", back_populates="kb")
    funcs = relationship("DbFunction", back_populates="kb")
    callgraphs = relationship("DbCallGraph", back_populates="kb")
    xrefs = relationship("DbXRefs", uselist=False, back_populates="kb")
    comments = relationship("DbComment", back_populates="kb")
    bookmarks = relationship("DbBookmark", back_populates="kb")
    labels = relationship("DbLabel", back_populates="kb")
    var_collections = relationship("DbVariableCollection", back_populates="kb")
    dec_var_collections = relationship("DbDecVariableCollection", back_populates="kb")
    structured_code = relationship("DbStructuredCode", back_populates="kb")
    decompilation_caches = relationship("DbDecompilationCache", back_populates="kb")


class DbCFGModel(Base):
    """
    Models a CFGFast instance.
    """

    __tablename__ = "cfgs"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="cfgs")
    ident = Column(String)
    blob = Column(BLOB)


class DbFunction(Base):
    """
    Models a Function instance.
    """

    __tablename__ = "functions"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="funcs")
    addr = Column(Integer)
    blob = Column(BLOB)


class DbCallGraph(Base):
    """
    Models the callgraph of a function manager.
    """

    __tablename__ = "callgraphs"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="callgraphs")
    blob = Column(BLOB, nullable=True)


class DbVariableCollection(Base):
    """
    Models a VariableManagerInternal instance.
    """

    __tablename__ = "variables"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="var_collections")
    func_addr = Column(Integer)
    ident = Column(String, nullable=True)
    blob = Column(BLOB)


class DbDecVariableCollection(Base):
    """
    Models a VariableManagerInternal instance of the decompilation variable manager (kb.dec_variables). A separate
    table from ``variables`` (the disassembly-level kb.variables) so databases created before it existed remain
    loadable: ``create_all`` adds missing tables.
    """

    __tablename__ = "dec_variables"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="dec_var_collections")
    func_addr = Column(Integer)
    ident = Column(String, nullable=True)
    blob = Column(BLOB)


class DbStructuredCode(Base):
    """
    Models a StructuredCode instance.
    """

    __tablename__ = "structured_code"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="structured_code")
    func_addr = Column(Integer)
    flavor = Column(String)
    expr_comments = Column(BLOB, nullable=True)
    stmt_comments = Column(BLOB, nullable=True)
    configuration = Column(BLOB, nullable=True)
    const_formats = Column(BLOB, nullable=True)
    ite_exprs = Column(BLOB, nullable=True)
    errors = Column(TEXT, nullable=True)


class DbDecompilationCache(Base):
    """
    Models a fully serialized DecompilationCache instance (a protobuf DecompilationCache message). A separate table
    from ``structured_code`` (which stores only codegen metadata) so databases created before it existed remain
    loadable: ``create_all`` adds missing tables.
    """

    __tablename__ = "decompilation_caches"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="decompilation_caches")
    func_addr = Column(Integer)
    flavor = Column(String)
    blob = Column(BLOB, nullable=True)


class DbXRefs(Base):
    """
    Models an XRefManager instance.
    """

    __tablename__ = "xrefs"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="xrefs")
    blob = Column(BLOB, nullable=True)


class DbComment(Base):
    """
    Models a comment.
    """

    __tablename__ = "comments"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="comments")
    addr = Column(Integer, index=True)
    comment = Column(String)
    # 0 = no explicit kind (defaults apply); otherwise CommentKind + 1
    type = Column(Integer)


class DbBookmark(Base):
    """
    Models a bookmark.
    """

    __tablename__ = "bookmarks"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="bookmarks")
    addr = Column(Integer, index=True)
    label = Column(String)
    created_at = Column(Float)


class DbLabel(Base):
    """
    Models a label.
    """

    __tablename__ = "labels"

    id = Column(Integer, primary_key=True)
    kb_id = Column(
        Integer,
        ForeignKey("knowledgebases.id"),
        nullable=False,
    )
    kb = relationship("DbKnowledgeBase", uselist=False, back_populates="labels")
    addr = Column(Integer, index=True)
    name = Column(String)
